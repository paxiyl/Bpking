package com.example.autoblock;

public final class BuildConfig {
    public static final String MODID = "autoblock";
    public static final String MODNAME = "AutoBlock";
    public static final String VERSION = "1.0.0";
}