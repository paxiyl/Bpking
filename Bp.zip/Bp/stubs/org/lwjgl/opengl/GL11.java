package org.lwjgl.opengl;

public class GL11 {
    public static final int GL_LINES = 1;
    public static final int GL_QUADS = 7;
    public static void glPushMatrix() {}
    public static void glPopMatrix() {}
    public static void glTranslated(double x, double y, double z) {}
    public static void glTranslatef(float x, float y, float z) {}
    public static void glRotatef(float angle, float x, float y, float z) {}
    public static void glScalef(float x, float y, float z) {}
    public static void glLineWidth(float width) {}
}