package org.lwjgl.input;

public class Keyboard {
    public static final int KEY_NONE = 0;
    public static final int KEY_F9 = 0x3E;
    public static final int KEY_F10 = 0x3F;
}