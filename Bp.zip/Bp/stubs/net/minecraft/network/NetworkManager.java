package net.minecraft.network;

public class NetworkManager {
    public boolean isChannelOpen() { return false; }
    public void processReceivedPackets() {}
    public void checkDisconnected() {}
}