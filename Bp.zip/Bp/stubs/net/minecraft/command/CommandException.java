package net.minecraft.command;

public class CommandException extends Exception {
    public CommandException(String s) { super(s); }
    public CommandException(String s, Object... args) { super(s); }
}