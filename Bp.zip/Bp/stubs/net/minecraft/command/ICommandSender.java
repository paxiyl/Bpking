package net.minecraft.command;

import net.minecraft.util.IChatComponent;

public interface ICommandSender {
    void addChatMessage(IChatComponent component);
}