package net.minecraft.util;

public enum EnumChatFormatting {
    BLACK, DARK_BLUE, DARK_GREEN, DARK_AQUA, DARK_RED, DARK_PURPLE, GOLD, GRAY,
    DARK_GRAY, BLUE, GREEN, AQUA, RED, LIGHT_PURPLE, YELLOW, WHITE,
    OBFUSCATED, BOLD, STRIKETHROUGH, UNDERLINE, ITALIC, RESET;
    @Override public String toString() { return "\u00a7" + this.ordinal(); }
}
