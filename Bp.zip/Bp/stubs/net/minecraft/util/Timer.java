package net.minecraft.util;

public class Timer {
    public float renderPartialTicks;
    public int elapsedTicks;
}
