package net.minecraft.util;

public class MovingObjectPosition {
    public enum MovingObjectType { MISS, BLOCK, ENTITY }
    public MovingObjectType typeOfHit;
    public EnumFacing sideHit;
    private BlockPos blockPos;
    public BlockPos getBlockPos() { return blockPos; }
}
