package net.minecraft.util;

public class Vec3 {
    public final double xCoord, yCoord, zCoord;
    public Vec3(double x, double y, double z) { this.xCoord = x; this.yCoord = y; this.zCoord = z; }
    public Vec3 addVector(double x, double y, double z) { return new Vec3(xCoord + x, yCoord + y, zCoord + z); }
    public Vec3 subtract(Vec3 o) { return new Vec3(xCoord - o.xCoord, yCoord - o.yCoord, zCoord - o.zCoord); }
    public Vec3 scale(double s) { return new Vec3(xCoord * s, yCoord * s, zCoord * s); }
    public Vec3 normalize() {
        double l = lengthVector();
        return l < 1.0E-4D ? new Vec3(0, 0, 0) : new Vec3(xCoord / l, yCoord / l, zCoord / l);
    }
    public double dotProduct(Vec3 o) { return xCoord * o.xCoord + yCoord * o.yCoord + zCoord * o.zCoord; }
    public double lengthVector() { return Math.sqrt(xCoord * xCoord + yCoord * yCoord + zCoord * zCoord); }
    public double distanceTo(Vec3 o) { return subtract(o).lengthVector(); }
}
