package net.minecraft.util;

public class MathHelper {
    public static int floor_double(double d) { return (int) Math.floor(d); }
    public static double clamp_double(double v, double min, double max) { return Math.max(min, Math.min(max, v)); }
    public static float clamp_float(float v, float min, float max) { return Math.max(min, Math.min(max, v)); }
    public static float wrapAngleTo180_float(float a) {
        a = a % 360.0F;
        if (a >= 180.0F) a -= 360.0F;
        if (a < -180.0F) a += 360.0F;
        return a;
    }
    public static float sin(float a) { return (float) Math.sin(a); }
    public static float cos(float a) { return (float) Math.cos(a); }
}
