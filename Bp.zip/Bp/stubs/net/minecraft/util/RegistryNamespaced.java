package net.minecraft.util;

import net.minecraft.block.Block;

public class RegistryNamespaced {
    public ResourceLocation getNameForObject(Block block) { return new ResourceLocation("minecraft:stone"); }
}
