package net.minecraft.util;

public class ResourceLocation {
    private final String s;
    public ResourceLocation(String s) { this.s = s; }
    @Override public String toString() { return s; }
}
