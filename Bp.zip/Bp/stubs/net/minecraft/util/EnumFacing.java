package net.minecraft.util;

public enum EnumFacing {
    DOWN(0, -1, 0), UP(0, 1, 0), NORTH(0, 0, -1), SOUTH(0, 0, 1), WEST(-1, 0, 0), EAST(1, 0, 0);

    public static final EnumFacing[] VALUES = values();
    private final int ox, oy, oz;
    EnumFacing(int ox, int oy, int oz) { this.ox = ox; this.oy = oy; this.oz = oz; }
    public int getFrontOffsetX() { return ox; }
    public int getFrontOffsetY() { return oy; }
    public int getFrontOffsetZ() { return oz; }
}
