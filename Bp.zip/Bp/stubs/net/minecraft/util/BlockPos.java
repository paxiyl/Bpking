package net.minecraft.util;

public class BlockPos {
    public static final BlockPos ORIGIN = new BlockPos(0, 0, 0);
    private final int x, y, z;
    public BlockPos(int x, int y, int z) { this.x = x; this.y = y; this.z = z; }
    public int getX() { return x; }
    public int getY() { return y; }
    public int getZ() { return z; }
    public BlockPos offset(EnumFacing f) { return new BlockPos(x + f.getFrontOffsetX(), y + f.getFrontOffsetY(), z + f.getFrontOffsetZ()); }
    public BlockPos offset(EnumFacing f, int n) { return new BlockPos(x + f.getFrontOffsetX() * n, y + f.getFrontOffsetY() * n, z + f.getFrontOffsetZ() * n); }
    public BlockPos add(int dx, int dy, int dz) { return new BlockPos(x + dx, y + dy, z + dz); }
    @Override public boolean equals(Object o) {
        if (!(o instanceof BlockPos)) return false;
        BlockPos p = (BlockPos) o;
        return p.x == x && p.y == y && p.z == z;
    }
    @Override public int hashCode() { return (x * 31 + y) * 31 + z; }
    @Override public String toString() { return "(" + x + ", " + y + ", " + z + ")"; }
}
