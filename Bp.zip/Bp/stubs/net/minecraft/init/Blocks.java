package net.minecraft.init;

import net.minecraft.block.Block;

public class Blocks {
    public static final Block air = new Block();
}