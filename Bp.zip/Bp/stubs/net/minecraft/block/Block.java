package net.minecraft.block;

import net.minecraft.block.state.IBlockState;
import net.minecraft.util.BlockPos;
import net.minecraft.world.World;

public class Block {
    public static final net.minecraft.util.RegistryNamespaced blockRegistry = new net.minecraft.util.RegistryNamespaced();
    public boolean isFullBlock() { return true; }
    public boolean isReplaceable(World world, BlockPos pos) { return false; }
    public static Block getBlockFromItem(net.minecraft.item.Item item) { return null; }
}