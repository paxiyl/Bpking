package net.minecraft.entity;

import java.util.UUID;

import net.minecraft.util.Vec3;
import net.minecraft.world.World;

public class Entity {
    public World worldObj;
    public double posX, posY, posZ, lastTickPosX, lastTickPosY, lastTickPosZ;
    public float rotationYaw, rotationPitch;
    public boolean isDead;

    public Vec3 getPositionEyes(float partialTicks) { return new Vec3(posX, posY, posZ); }
    public float getDistanceToEntity(Entity entity) { return 0.0F; }
    public UUID getUniqueID() { return UUID.randomUUID(); }
}