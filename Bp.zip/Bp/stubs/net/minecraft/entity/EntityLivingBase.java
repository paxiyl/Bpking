package net.minecraft.entity;

public class EntityLivingBase extends Entity {
    public void swingItem() {}
}