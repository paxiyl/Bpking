package net.minecraft.entity.player;

import net.minecraft.item.ItemStack;

public class InventoryPlayer {
    public int currentItem = 0;
    public ItemStack[] mainInventory = new ItemStack[36];
    public ItemStack getCurrentItem() { return currentItem >= 0 && currentItem < mainInventory.length ? mainInventory[currentItem] : null; }
}