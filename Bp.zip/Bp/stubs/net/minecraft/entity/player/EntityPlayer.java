package net.minecraft.entity.player;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.ItemStack;

public class EntityPlayer extends EntityLivingBase {
    public InventoryPlayer inventory = new InventoryPlayer();
    public ItemStack getHeldItem() { return inventory.getCurrentItem(); }
    public boolean isPlayerSleeping() { return false; }
    public String getName() { return "Player"; }
}