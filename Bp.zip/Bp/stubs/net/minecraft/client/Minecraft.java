package net.minecraft.client;

import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.multiplayer.PlayerControllerMP;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.client.renderer.RenderManager;

public class Minecraft {
    private static final Minecraft INSTANCE = new Minecraft();
    public static Minecraft getMinecraft() { return INSTANCE; }
    public EntityPlayerSP thePlayer;
    public WorldClient theWorld;
    public PlayerControllerMP playerController;
    public GuiScreen currentScreen;
    public FontRenderer fontRendererObj;
    public net.minecraft.util.Timer timer = new net.minecraft.util.Timer();
    public NetHandlerPlayClient getNetHandler() { return null; }
    public RenderManager getRenderManager() { return null; }
    public boolean isSingleplayer() { return false; }
}