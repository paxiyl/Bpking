package net.minecraft.client.entity;

import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.entity.player.EntityPlayer;

public class EntityPlayerSP extends EntityPlayer {
    public NetHandlerPlayClient sendQueue;
}