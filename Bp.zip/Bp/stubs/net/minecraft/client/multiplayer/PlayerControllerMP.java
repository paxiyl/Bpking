package net.minecraft.client.multiplayer;

import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.item.ItemStack;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.Vec3;

public class PlayerControllerMP {
    private final Minecraft mc;
    public PlayerControllerMP(Minecraft mcIn, NetHandlerPlayClient netHandler) { this.mc = mcIn; }
    public float getBlockReachDistance() { return 4.5F; }
    public boolean isInCreativeMode() { return false; }
    public boolean onPlayerRightClick(EntityPlayerSP player, WorldClient worldIn, ItemStack heldStack,
                                      BlockPos hitPos, EnumFacing side, Vec3 hitVec) { return false; }
    public void syncCurrentPlayItem() {}
}