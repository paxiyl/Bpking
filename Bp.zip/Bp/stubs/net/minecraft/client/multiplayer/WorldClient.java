package net.minecraft.client.multiplayer;

public class WorldClient extends net.minecraft.world.World {
}