package net.minecraft.client.gui;

public class FontRenderer {
    public int getStringWidth(String s) { return s.length() * 5; }
    public int drawString(String text, int x, int y, int color) { return x; }
    public int drawStringWithShadow(String text, int x, int y, int color) { return x; }
}