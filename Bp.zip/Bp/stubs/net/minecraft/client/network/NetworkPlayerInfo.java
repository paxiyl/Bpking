package net.minecraft.client.network;

public class NetworkPlayerInfo {
    private int responseTime;
    public int getResponseTime() { return responseTime; }
}