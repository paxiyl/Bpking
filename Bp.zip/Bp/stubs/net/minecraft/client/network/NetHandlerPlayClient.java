package net.minecraft.client.network;

import java.util.UUID;

import net.minecraft.network.NetworkManager;

public class NetHandlerPlayClient {
    public NetworkPlayerInfo getPlayerInfo(UUID uuid) { return null; }
    public NetworkManager getNetworkManager() { return null; }
}