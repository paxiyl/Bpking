package net.minecraft.client.renderer.vertex;

public class DefaultVertexFormats {
    public static final VertexFormat POSITION_COLOR = new VertexFormat();
    public static final VertexFormat POSITION_TEX = new VertexFormat();
}