package net.minecraft.client.renderer;

import net.minecraft.entity.Entity;

public class RenderManager {
    public Entity renderViewEntity;
    public float playerViewX;
    public float playerViewY;
    public double viewerPosX, viewerPosY, viewerPosZ;
}