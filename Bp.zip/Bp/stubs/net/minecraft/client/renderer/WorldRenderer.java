package net.minecraft.client.renderer;

public class WorldRenderer {
    public void begin(int mode, net.minecraft.client.renderer.vertex.VertexFormat format) {}
    public WorldRenderer pos(double x, double y, double z) { return this; }
    public WorldRenderer color(float r, float g, float b, float a) { return this; }
    public void endVertex() {}
}