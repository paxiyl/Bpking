package net.minecraft.world;

import java.util.ArrayList;
import java.util.List;

import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.Vec3;

public class World {
    public final List<EntityPlayer> playerEntities = new ArrayList<EntityPlayer>();
    public IBlockState getBlockState(BlockPos pos) { return null; }
    public MovingObjectPosition rayTraceBlocks(Vec3 start, Vec3 end) { return null; }
    public long getTotalWorldTime() { return 0L; }
}