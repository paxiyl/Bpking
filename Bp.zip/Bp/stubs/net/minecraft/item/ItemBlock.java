package net.minecraft.item;

public class ItemBlock extends Item {
    private final net.minecraft.block.Block block;
    public ItemBlock(net.minecraft.block.Block block) { this.block = block; }
    public net.minecraft.block.Block getBlock() { return block; }
}