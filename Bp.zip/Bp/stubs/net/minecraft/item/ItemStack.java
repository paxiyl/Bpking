package net.minecraft.item;

public class ItemStack {
    public int stackSize;
    private final Item item;
    public ItemStack(Item item) { this.item = item; }
    public Item getItem() { return item; }
}