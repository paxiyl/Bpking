package net.minecraftforge.fml.common.gameevent;

public class TickEvent {
    public enum Phase { START, END }

    public static class ClientTickEvent extends TickEvent {
        public final Phase phase;
        public ClientTickEvent(Phase phase) { this.phase = phase; }
    }
}