package net.minecraftforge.client.event;

public class RenderWorldLastEvent {
    private final float partialTicks;
    public RenderWorldLastEvent(float partialTicks) { this.partialTicks = partialTicks; }
    public float getPartialTicks() { return partialTicks; }
}