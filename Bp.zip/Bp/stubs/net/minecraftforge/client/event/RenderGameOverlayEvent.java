package net.minecraftforge.client.event;

import java.util.ArrayList;
import java.util.List;

public class RenderGameOverlayEvent {
    public enum ElementType { TEXT }

    public static class Text extends RenderGameOverlayEvent {
        public final ElementType type;
        public final List<String> text = new ArrayList<String>();
        public Text(ElementType type) { this.type = type; }
    }
}