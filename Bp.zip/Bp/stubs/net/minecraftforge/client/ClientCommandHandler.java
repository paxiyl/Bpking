package net.minecraftforge.client;

import net.minecraft.command.ICommand;

public class ClientCommandHandler {
    public static final ClientCommandHandler instance = new ClientCommandHandler();
    public void registerCommand(ICommand command) {}
}