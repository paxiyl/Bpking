package net.minecraftforge.common;

public class MinecraftForge {
    public static final EventBus EVENT_BUS = new EventBus();
}