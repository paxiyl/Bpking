package net.minecraftforge.common;

public class EventBus {
    public void register(Object o) {}
    public void unregister(Object o) {}
}