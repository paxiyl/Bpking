package net.minecraftforge.common.config;

import java.io.File;
import java.util.Set;

public class Configuration {
    public static final String CATEGORY_GENERAL = "general";
    public Configuration(File file) {}
    public void load() {}
    public void save() {}
    public boolean hasChanged() { return false; }
    public Property get(String category, String key, boolean defaultValue) { return new Property(); }
    public Property get(String category, String key, boolean defaultValue, String comment) { return new Property(); }
    public Property get(String category, String key, int defaultValue) { return new Property(); }
    public Property get(String category, String key, int defaultValue, int minValue, int maxValue) { return new Property(); }
    public Property get(String category, String key, int defaultValue, String comment, int minValue, int maxValue) { return new Property(); }
    public Property get(String category, String key, String defaultValue) { return new Property(); }
    public Property get(String category, String key, String defaultValue, String comment) { return new Property(); }
    public Property get(String category, String key, double defaultValue, double minValue, double maxValue) { return new Property(); }
    public Property get(String category, String key, double defaultValue, String comment, double minValue, double maxValue) { return new Property(); }
    public String[] getStringList(String key, String category, String[] defaultValue, String comment) { return defaultValue; }
    public boolean getBoolean(String key, String category, boolean defaultValue, String comment) { return defaultValue; }
    public Set<String> getCategoryNames() { return null; }

    public static class Property {
        public boolean getBoolean() { return false; }
        public boolean getBoolean(boolean defaultValue) { return defaultValue; }
        public int getInt() { return 0; }
        public int getInt(int defaultValue) { return defaultValue; }
        public double getDouble() { return 0.0D; }
        public double getDouble(double defaultValue) { return defaultValue; }
        public String getString() { return ""; }
        public boolean isList() { return false; }
        public String[] getStringList() { return new String[0]; }
    }
}