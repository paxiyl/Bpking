# AutoBlock — Predictive Horizontal 3-Block Placement System (Minecraft 1.8.9 Forge)

A Forge 1.8.9 client mod for **private servers, single-player worlds, or controlled
testing environments**. The mod tracks an eligible target, predicts where it will be,
and places a **three-block horizontal wall** directly in its path — using the **local
player's actual position, camera/POV, reach, inventory and normal Minecraft block
placement mechanics**.

```
                 TARGET
                   |
                   v   movement direction
              [LEFT][CENTER][RIGHT]
                   ^
              LOCAL PLAYER
```

The server remains fully authoritative: the mod never fakes remote block placement,
never directly modifies the world, never teleports the player, never spoofs ping,
and never fabricates block confirmations.

---

## Build

See [BUILDING.md](BUILDING.md). Requires **Java 8** + Gradle 4.5 (wrapper included):

```
./gradlew setupDecompWorkspace
./gradlew build        # jar -> build/libs/AutoBlock-1.0.0.jar
./gradlew runClient    # launch a dev client
```

---

## Usage

| Action | Command / Key |
|---|---|
| Enable / disable | `/autoblock on` / `/autoblock off` (or `toggle`) |
| Debug overlay | F9 or `/autoblock overlay` |
| World visualization | F10 or `/autoblock viz` |
| Target: nearest player (auto) | `/autoblock target auto` |
| Target: lock by name | `/autoblock target set <playername>` |
| Target: none | `/autoblock target none` |
| Status dump | `/autoblock info` |
| Reload config | `/autoblock reload` |

The mod engages only when the target is **moving toward the local player** above a
minimum speed. While the sequence runs, the state machine walks through:

```
TARGET_FOUND -> PREDICT_TARGET -> CALCULATE_ROW -> SOLVE_REACH
-> (per block) VALIDATE_BLOCK_N -> ROTATE_TO_BLOCK_N -> VERIFY_VIEW_BLOCK_N
   -> PLACE_BLOCK_N -> CONFIRM_BLOCK_N
-> COMPLETE
```

Any of `TARGET_LOST`, `TARGET_CHANGED`, `PLACEMENT_INVALID`, `OUT_OF_REACH`,
`BLOCK_REJECTED` or `WORLD_CHANGED` sends the machine into `RECALCULATE` — or
`ABORT` after too many attempts.

### Controlled test setup (single player)

Because targeting is player-based, test with **two clients** (LAN on 1.8.9 is supported):

1. World A: place the local player in an open arena with a few stacks of a wall
   block (e.g. cobblestone) in the hotbar.
2. World B (second client, joined via LAN): the target player runs toward World A's
   player across flat ground within ~32 blocks.
3. The mod predicts the target's path, rotates the local player's camera onto the
   placement faces, and places `[LEFT][CENTER][RIGHT]` at ground level in the target's
   path, confirming each block against the authoritative world state.

---

## Configuration

`config/autoblock.cfg` (reload with `/autoblock reload`). All values documented
in-file; highlights:

- `targeting.*` — auto target on/off, range, minimum speed, approach angle.
- `prediction.*` — prediction window (ticks), velocity/acceleration smoothing,
  RTT compensation, max prediction time.
- `recalculation.*` — direction-change/drift thresholds, retry budgets.
- `placement.*` — wall lead offset, block whitelist (registry names), swing
  animation on/off, strict line-of-sight requirement.
- `rotation.*` — snap vs. smooth rotation, degrees-per-tick speed, tolerance.
- `confirmation.*` — minimum and adaptive (RTT-scaled) confirmation delay, timeout.
- `reach.*` — optional reach override (0.0 = vanilla 4.5/5.0, capped at the
  server's 6.0-block placement limit).
- `debug.*` — overlay/visualization defaults, console logging.

---

## How it works

- **Targeting** (`TargetDetector`) — nearest player in range, or a name-locked target.
- **Prediction** (`MovementPredictor`) — samples the target every client tick, EMA
  smooths velocity (and acceleration), and projects `pos + v·t + ½a·t²` where
  `t = predictionWindowTicks·tickTime + estimatedRTT`.
- **Wall geometry** (`HorizontalRowCalculator`) — center block under the predicted
  foot position; left/right extend along the perpendicular `(-dirZ, dirX)`.
- **Reach solver** (`PlayerReachSolver`) — evaluates the current position against
  the player's **eye** position, vanilla reach and ray-traced line of sight.
  Advisory only — the player is never moved.
- **Rotation** (`RotationController`) — computes yaw/pitch to each **face interaction
  point** and eases the actual camera through the client tick system (no sleeps).
- **Placement** (`PlacementController` + `PlacementValidator`) — picks a dynamic
  block order and placement faces (ground, or faces on already-confirmed wall
  blocks), selects the correct hotbar slot, then performs the placement through
  the vanilla `PlayerControllerMP.onPlayerRightClick` path (the server receives
  the normal `C08PacketPlayerBlockPlacement` and stays authoritative).
- **Confirmation** (`ConfirmationTracker`) — after every placement the authoritative
  world state is polled (delay scaled by estimated RTT) and compared with the
  expected block. Only a match yields `CONFIRMED`; anything else yields `FAILED`
  and triggers recovery. Ghost blocks are never assumed.
- **Network diagnostics** (`NetworkDiagnostics`) — read-only observation of the
  reported RTT (`NetworkPlayerInfo.getResponseTime`), tick timing and
  send→confirm delay. Nothing is spoofed or suppressed.
- **Debug** (`DebugOverlay` / `DebugRenderer`) — full HUD overlay plus world-space
  rendering of the wall, predicted/current target positions, movement vector,
  eye marker, placement face and reach line.

---

## Architecture

```
com.example.autoblock
├── AutoBlockMod.java            @Mod entry point, wiring
├── AutoBlockKeys.java           F9/F10 bindings
├── command/CommandAutoBlock.java
├── config/ModConfig.java
├── target/
│   ├── TargetDetector.java
│   └── MovementPredictor.java
├── geometry/
│   ├── HorizontalRowCalculator.java
│   ├── PlacementPlan.java
│   └── PlacementStep.java
├── player/
│   ├── PlayerState.java
│   └── PlayerReachSolver.java
├── rotation/
│   └── RotationController.java
├── placement/
│   ├── PlacementValidator.java
│   ├── PlacementController.java
│   └── ConfirmationTracker.java
├── network/
│   └── NetworkDiagnostics.java
└── render/
    ├── DebugOverlay.java
    └── DebugRenderer.java
```

---

## Strict rules honored

- Uses the local player's actual POV, position and eye position.
- Respects normal reach and line of sight (ray-traced).
- Uses legitimate block interaction (vanilla placement path, server-authoritative).
- Waits for authoritative confirmation before advancing.
- Recalculates when the target changes direction or drifts.
- Never directly modifies world blocks, never fabricates confirmations,
  never suppresses server corrections, never spoofs ping, never teleports,
  never blocks the main thread, never assumes a placement succeeded.

## License

For controlled/private environments only. Use at your own risk — as with any
automation mod, server rules and community guidelines apply.
