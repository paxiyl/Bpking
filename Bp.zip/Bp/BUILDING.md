# Building AutoBlock (Forge 1.8.9)

## Requirements

- **JDK 8** — mandatory. The 1.8.9 Forge toolchain (ForgeGradle 2.1 + Gradle 4.5)
  does not work on newer JDKs. Any Java 8 distribution works:
  - Adoptium Temurin 8: https://adoptium.net/temurin/releases/?version=8
  - Azul Zulu 8: https://www.azul.com/downloads/?version=java-8-lts
- Network access (first build downloads Minecraft 1.8.9, Forge and the
  `stable_22` mappings).
- ~3 GB free disk space for the decompile workspace.

## Desktop (Linux / macOS / Windows)

```bash
export JAVA_HOME=/path/to/jdk8          # Windows: set JAVA_HOME=C:\...\jdk8
./gradlew setupDecompWorkspace           # Windows: gradlew.bat
./gradlew build                          # jar -> build/libs/AutoBlock-1.0.0.jar
```

Run a dev client (optional):

```bash
./gradlew runClient
```

The produced jar goes into `build/libs/` and drops straight into the
`.minecraft/mods` folder of a Forge **1.8.9-11.15.1.2318-1.8.9** client.

## GitHub Actions

A workflow is included (`.github/workflows/build.yml`). Push the repository to
GitHub and the `Build` workflow will compile with Temurin 8 and attach the jar
as a build artifact (`Actions > Build > Upload artifacts`).

## Troubleshooting

- `Could not find net.minecraftforge.gradle:ForgeGradle:2.1-SNAPSHOT` — check
  network access to `https://maven.minecraftforge.net/`; corporate proxies need
  the forge maven on the allowlist.
- Gradle errors about `stable_22` mappings — ensure the minecraft block in
  `build.gradle` still says `version = "1.8.9-11.15.1.2318-1.8.9"` and
  `mappings = "stable_22"`.
- Running with a JDK newer than 8 (e.g. 11/17/21) fails in ForgeGradle — switch
  `JAVA_HOME` (and IDE Gradle JVM) back to Java 8.
- `gradlew` not executable — `chmod +x gradlew` (Linux/macOS).

## Clean rebuild

```bash
./gradlew clean
./gradlew setupDecompWorkspace
./gradlew build
```
