package com.example.autoblock.player;

import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.util.Vec3;

/**
 * Snapshot of the local player's actual state at a point in time:
 * position, eye position, rotation, reach and held-item facts.
 * Everything the placement logic must be derived from.
 */
public class PlayerState {

    public final double x, y, z;
    public final double eyeX, eyeY, eyeZ;
    public final float yaw, pitch;
    public final double reach;
    public final boolean creative;
    public final boolean hasBlockInHand;

    private PlayerState(double x, double y, double z, double eyeX, double eyeY, double eyeZ,
                        float yaw, float pitch, double reach, boolean creative, boolean hasBlockInHand) {
        this.x = x;
        this.y = y;
        this.z = z;
        this.eyeX = eyeX;
        this.eyeY = eyeY;
        this.eyeZ = eyeZ;
        this.yaw = yaw;
        this.pitch = pitch;
        this.reach = reach;
        this.creative = creative;
        this.hasBlockInHand = hasBlockInHand;
    }

    public static PlayerState capture(Minecraft mc) {
        EntityPlayerSP p = mc.thePlayer;
        Vec3 eye = p.getPositionEyes(1.0F);
        return new PlayerState(
                p.posX, p.posY, p.posZ,
                eye.xCoord, eye.yCoord, eye.zCoord,
                p.rotationYaw, p.rotationPitch,
                mc.playerController.getBlockReachDistance(),
                mc.playerController.isInCreativeMode(),
                p.getHeldItem() != null && p.getHeldItem().getItem() instanceof net.minecraft.item.ItemBlock);
    }

    public Vec3 eyeVec() {
        return new Vec3(eyeX, eyeY, eyeZ);
    }

    public double distanceTo(Vec3 v) {
        double dx = v.xCoord - eyeX;
        double dy = v.yCoord - eyeY;
        double dz = v.zCoord - eyeZ;
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }
}
