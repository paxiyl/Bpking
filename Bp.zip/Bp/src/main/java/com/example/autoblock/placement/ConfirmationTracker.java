package com.example.autoblock.placement;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import com.example.autoblock.config.ModConfig;
import com.example.autoblock.network.NetworkDiagnostics;

import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.util.BlockPos;

/**
 * Ghost-block prevention. After a placement request we never assume success:
 * the authoritative world state is polled after a (possibly RTT-scaled)
 * delay and compared against the expected block. Only a match produces
 * CONFIRMED; anything else produces FAILED.
 */
public class ConfirmationTracker {

    public enum Result {
        WAITING,
        CONFIRMED,
        FAILED
    }

    private static class Pending {
        final BlockPos pos;
        final Block expected;
        final long placedTick;
        final long minDelayTicks;

        Pending(BlockPos pos, Block expected, long placedTick, long minDelayTicks) {
            this.pos = pos;
            this.expected = expected;
            this.placedTick = placedTick;
            this.minDelayTicks = minDelayTicks;
        }
    }

    private final ModConfig config;
    private final NetworkDiagnostics network;

    private final Map<BlockPos, Pending> pending = new HashMap<BlockPos, Pending>();
    private final Map<BlockPos, Result> results = new HashMap<BlockPos, Result>();

    public ConfirmationTracker(ModConfig config, NetworkDiagnostics network) {
        this.config = config;
        this.network = network;
    }

    public void registerPlacement(BlockPos pos, Block expected) {
        Minecraft mc = Minecraft.getMinecraft();
        long tick = mc.theWorld != null ? mc.theWorld.getTotalWorldTime() : 0L;
        pending.put(pos, new Pending(pos, expected, tick, network.confirmationDelayTicks()));
    }

    public void onClientTick(Minecraft mc) {
        if (mc.theWorld == null) {
            return;
        }
        long tick = mc.theWorld.getTotalWorldTime();
        Iterator<Map.Entry<BlockPos, Pending>> it = pending.entrySet().iterator();
        while (it.hasNext()) {
            Pending p = it.next().getValue();
            long elapsed = tick - p.placedTick;
            Block actual = mc.theWorld.getBlockState(p.pos).getBlock();
            if (actual == p.expected) {
                // Client prediction visible; keep watching until the RTT window
                // has passed, so a server rejection would still be detected.
                if (elapsed >= p.minDelayTicks) {
                    results.put(p.pos, Result.CONFIRMED);
                    it.remove();
                }
            } else if (elapsed >= p.minDelayTicks) {
                results.put(p.pos, Result.FAILED);
                it.remove();
            } else if (elapsed >= config.confirmTimeoutTicks) {
                results.put(p.pos, actual == p.expected ? Result.CONFIRMED : Result.FAILED);
                it.remove();
            }
        }
    }

    public Result getResult(BlockPos pos) {
        Result r = results.get(pos);
        return r == null ? Result.WAITING : r;
    }

    public void clear() {
        pending.clear();
        results.clear();
    }
}
