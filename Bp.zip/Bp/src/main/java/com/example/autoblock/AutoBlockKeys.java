package com.example.autoblock;

import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import org.lwjgl.input.Keyboard;

public class AutoBlockKeys {

    private static final String CATEGORY = "key.categories.autoblock";

    public static final KeyBinding TOGGLE = new KeyBinding("key.autoblock.toggle", Keyboard.KEY_NONE, CATEGORY);
    public static final KeyBinding OVERLAY = new KeyBinding("key.autoblock.overlay", Keyboard.KEY_F9, CATEGORY);
    public static final KeyBinding VISUALIZATION = new KeyBinding("key.autoblock.visualization", Keyboard.KEY_F10, CATEGORY);

    public static void register() {
        ClientRegistry.registerKeyBinding(TOGGLE);
        ClientRegistry.registerKeyBinding(OVERLAY);
        ClientRegistry.registerKeyBinding(VISUALIZATION);
    }

    @SubscribeEvent
    public void onKeyInput(InputEvent.KeyInputEvent event) {
        AutoBlockMod mod = AutoBlockMod.instance;
        if (mod == null || mod.config == null) {
            return;
        }
        if (TOGGLE.isPressed()) {
            mod.config.enabled = !mod.config.enabled;
        }
        if (OVERLAY.isPressed()) {
            mod.config.showOverlay = !mod.config.showOverlay;
        }
        if (VISUALIZATION.isPressed()) {
            mod.config.showVisualization = !mod.config.showVisualization;
        }
    }
}
