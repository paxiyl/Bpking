package com.example.autoblock.network;

import java.util.UUID;

import com.example.autoblock.config.ModConfig;

import net.minecraft.client.Minecraft;
import net.minecraft.client.network.NetworkPlayerInfo;

/**
 * Observes timing information only. Never spoofs ping, never touches packets,
 * never suppresses server corrections - the server stays authoritative.
 */
public class NetworkDiagnostics {

    public static final long NANO_PER_MS = 1_000_000L;

    private final ModConfig config;

    private long lastTickNano = System.nanoTime();
    private double tickMs = 50.0D;

    private boolean rttKnown = false;
    private double rttMs = 0.0D;
    private int rttSamples = 0;

    private long lastPlacementSentNano = 0L;
    private long lastPlacementConfirmedNano = 0L;
    private double lastPlacementDelayMs = 0.0D;
    private double avgPlacementDelayMs = 0.0D;
    private int placementCount = 0;

    public NetworkDiagnostics(ModConfig config) {
        this.config = config;
    }

    public void onClientTick() {
        long now = System.nanoTime();
        double ms = (double) (now - lastTickNano) / NANO_PER_MS;
        if (ms > 0.0D && ms < 500.0D) {
            tickMs = tickMs * 0.9D + ms * 0.1D;
        }
        lastTickNano = now;
    }

    /** Reads the reported RTT from the player list. Read-only observation. */
    public void updatePing(UUID uuid) {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.getNetHandler() == null || uuid == null) {
            return;
        }
        NetworkPlayerInfo info = mc.getNetHandler().getPlayerInfo(uuid);
        if (info == null) {
            return;
        }
        int ping = info.getResponseTime();
        if (ping > 0) {
            if (rttKnown) {
                rttMs = rttMs * 0.8D + ping * 0.2D;
            } else {
                rttMs = ping;
                rttKnown = true;
            }
            rttSamples++;
        }
    }

    public boolean isRttKnown() {
        return rttKnown;
    }

    public double getRttMs() {
        return rttKnown ? rttMs : 0.0D;
    }

    public int getRttSamples() {
        return rttSamples;
    }

    public double getTickMs() {
        return tickMs;
    }

    public double rttToTicks() {
        return tickMs > 0.0D ? getRttMs() / tickMs : 0.0D;
    }

    public void markPlacementSent() {
        lastPlacementSentNano = System.nanoTime();
    }

    public void markPlacementConfirmed() {
        lastPlacementConfirmedNano = System.nanoTime();
        double d = (double) (lastPlacementConfirmedNano - lastPlacementSentNano) / NANO_PER_MS;
        if (d > 0.0D) {
            lastPlacementDelayMs = d;
            avgPlacementDelayMs = placementCount == 0 ? d : avgPlacementDelayMs * 0.7D + d * 0.3D;
            placementCount++;
        }
    }

    public double getLastPlacementDelayMs() {
        return lastPlacementDelayMs;
    }

    public double getAvgPlacementDelayMs() {
        return avgPlacementDelayMs;
    }

    public int getPlacementCount() {
        return placementCount;
    }

    /** Adaptive confirmation delay in ticks: scaled to the RTT when online. */
    public long confirmationDelayTicks() {
        if (config.adaptiveConfirmDelay && rttKnown) {
            long fromRtt = (long) Math.ceil(rttToTicks()) + 1L;
            return Math.max(config.confirmMinDelayTicks, fromRtt);
        }
        return config.confirmMinDelayTicks;
    }
}
