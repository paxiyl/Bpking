package com.example.autoblock.player;

import com.example.autoblock.config.ModConfig;
import com.example.autoblock.geometry.PlacementPlan;
import com.example.autoblock.geometry.PlacementStep;

import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.Vec3;
import net.minecraft.world.World;

/**
 * Determines whether the local player's current position can legitimately
 * reach all three wall blocks, using the eye position (not the feet).
 *
 * It only evaluates and advises - it never teleports or forces the player.
 */
public class PlayerReachSolver {

    public static final double EPS = 0.05D;

    private final ModConfig config;

    public PlayerReachSolver(ModConfig config) {
        this.config = config;
    }

    public static class ReachResult {
        public final boolean allReachable;
        public final boolean[] perBlock; // [0]=left [1]=center [2]=right
        public final Vec3 recommendedStand;
        public final boolean recommendedValid;

        public ReachResult(boolean allReachable, boolean[] perBlock, Vec3 recommendedStand, boolean recommendedValid) {
            this.allReachable = allReachable;
            this.perBlock = perBlock;
            this.recommendedStand = recommendedStand;
            this.recommendedValid = recommendedValid;
        }
    }

    public ReachResult solve(EntityPlayerSP player, Vec3 eye, double reach, PlacementPlan plan) {
        BlockPos[] positions = new BlockPos[]{plan.left, plan.center, plan.right};
        boolean[] ok = new boolean[3];
        boolean all = true;
        for (int i = 0; i < 3; i++) {
            Vec3 center = PlacementStep.blockCenter(positions[i]);
            ok[i] = eye.distanceTo(center) <= reach + EPS && clearToBlock(player.worldObj, eye, center);
            if (!ok[i]) {
                all = false;
            }
        }

        Vec3 recommended = computeRecommendedStand(positions, eye, reach);
        return new ReachResult(all, ok, recommended, recommended != null);
    }

    /** Advisory stand position along the player->wall line so all blocks are within reach. */
    private Vec3 computeRecommendedStand(BlockPos[] positions, Vec3 eye, double reach) {
        Vec3 wallCenter = PlacementStep.blockCenter(positions[1]);
        double dx = eye.xCoord - wallCenter.xCoord;
        double dz = eye.zCoord - wallCenter.zCoord;
        double len = Math.sqrt(dx * dx + dz * dz);
        Vec3 n = len > 1.0e-6D ? new Vec3(dx / len, 0.0D, dz / len) : new Vec3(0.0D, 0.0D, -1.0D);
        double margin = Math.min(0.25D, reach * 0.1D);
        for (double d = 0.5D; d <= 24.0D; d += 0.25D) {
            Vec3 cand = new Vec3(wallCenter.xCoord + n.xCoord * d, eye.yCoord, wallCenter.zCoord + n.zCoord * d);
            boolean fits = true;
            for (BlockPos p : positions) {
                if (cand.distanceTo(PlacementStep.blockCenter(p)) > reach - margin) {
                    fits = false;
                    break;
                }
            }
            if (fits) {
                return cand;
            }
        }
        return null;
    }

    /**
     * Approximate line-of-sight from the eye to a point: the ray must not hit
     * any block that is not the destination block.
     */
    public static boolean clearToBlock(World world, Vec3 eye, Vec3 point) {
        MovingObjectPosition mop = world.rayTraceBlocks(eye, point);
        if (mop == null) {
            return true;
        }
        if (mop.typeOfHit == MovingObjectPosition.MovingObjectType.BLOCK) {
            BlockPos hit = mop.getBlockPos();
            int hx = hit.getX(), hy = hit.getY(), hz = hit.getZ();
            return hx == Math.floor(point.xCoord) && hy == Math.floor(point.yCoord) && hz == Math.floor(point.zCoord);
        }
        return false;
    }
}
