package com.example.autoblock.render;

import com.example.autoblock.config.ModConfig;
import com.example.autoblock.geometry.PlacementPlan;
import com.example.autoblock.geometry.PlacementStep;
import com.example.autoblock.network.NetworkDiagnostics;
import com.example.autoblock.placement.ConfirmationTracker;
import com.example.autoblock.placement.PlacementController;
import com.example.autoblock.rotation.RotationController;
import com.example.autoblock.target.MovementPredictor;
import com.example.autoblock.target.TargetDetector;

import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.BlockPos;
import net.minecraft.util.Vec3;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

/**
 * Toggleable debug overlay (F9 / /autoblock overlay).
 */
public class DebugOverlay {

    private final ModConfig config;
    private final PlacementController controller;
    private final TargetDetector detector;
    private final MovementPredictor predictor;
    private final NetworkDiagnostics network;
    private final ConfirmationTracker tracker;

    public DebugOverlay(ModConfig config, PlacementController controller, TargetDetector detector,
                        MovementPredictor predictor, NetworkDiagnostics network, ConfirmationTracker tracker) {
        this.config = config;
        this.controller = controller;
        this.detector = detector;
        this.predictor = predictor;
        this.network = network;
        this.tracker = tracker;
    }

    @SubscribeEvent
    public void onRenderText(RenderGameOverlayEvent.Text event) {
        if (event.type != RenderGameOverlayEvent.ElementType.TEXT) {
            return;
        }
        if (!config.showOverlay) {
            return;
        }
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.thePlayer == null || mc.theWorld == null) {
            return;
        }
        EntityPlayerSP p = mc.thePlayer;
        EntityPlayer target = detector.getTarget();
        PlacementPlan plan = controller.getPlan();
        Vec3 predicted = controller.getPredicted();
        Vec3 dir = predictor.getDirectionHoriz();
        Vec3 eye = p.getPositionEyes(1.0F);
        PlacementStep step = controller.getCurrentStep();
        double reach = controller.effectiveReachForDisplay(mc);
        double aimOffset = -1.0D;
        if (step != null) {
            Vec3 lv = RotationController.lookVec(p.rotationYaw, p.rotationPitch);
            Vec3 d = step.interactionPoint.subtract(eye);
            double len = d.lengthVector();
            if (len > 1.0e-9D) {
                d = d.scale(1.0D / len);
                aimOffset = RotationController.angleDeg(lv, d);
            }
        }

        event.text.add("AutoBlock [" + (config.enabled ? "ON" : "OFF") + "] state=" + controller.getStateName());
        if (!controller.getLastMessage().isEmpty()) {
            event.text.add("Last event: " + controller.getLastMessage());
        }

        event.text.add("TARGET");
        if (target != null) {
            event.text.add(String.format("  %s | dist %.2f | vel %.2f b/s | dir (%.2f, %.2f)",
                    target.getName(), target.getDistanceToEntity(p), predictor.getSpeedHoriz(),
                    dir != null ? dir.xCoord : 0.0D, dir != null ? dir.zCoord : 0.0D));
        } else {
            event.text.add("  none");
        }

        event.text.add("PREDICTION");
        if (predicted != null) {
            event.text.add(String.format("  X %.2f  Y %.2f  Z %.2f", predicted.xCoord, predicted.yCoord, predicted.zCoord));
            event.text.add(String.format("  time %.2fs (rtt %.0f ms)", predictor.predictionSeconds(), network.getRttMs()));
        } else {
            event.text.add("  no prediction");
        }

        event.text.add("PLAYER");
        event.text.add(String.format("  X %.2f  Y %.2f  Z %.2f", p.posX, p.posY, p.posZ));
        event.text.add(String.format("  Eye X %.2f  Y %.2f  Z %.2f", eye.xCoord, eye.yCoord, eye.zCoord));

        event.text.add("NETWORK");
        event.text.add(String.format("  RTT %.0f ms (%d samples) | tick %.1f ms",
                network.getRttMs(), network.getRttSamples(), network.getTickMs()));
        event.text.add(String.format("  placement delay last %.0f ms / avg %.0f ms",
                network.getLastPlacementDelayMs(), network.getAvgPlacementDelayMs()));

        event.text.add("BLOCK ROW");
        if (plan != null) {
            event.text.add("  Left " + plan.left);
            event.text.add("  Center " + plan.center);
            event.text.add("  Right " + plan.right);
        } else {
            event.text.add("  no plan");
        }

        event.text.add("PLACEMENT");
        if (plan != null) {
            for (BlockPos pos : plan.all()) {
                event.text.add("  " + plan.label(pos) + ": " + statusOf(pos));
            }
        }

        event.text.add("CAMERA");
        float requiredYaw = 0.0F;
        float requiredPitch = 0.0F;
        if (step != null) {
            requiredYaw = RotationController.yawTo(eye, step.interactionPoint);
            requiredPitch = RotationController.pitchTo(eye, step.interactionPoint);
        }
        event.text.add(String.format("  required yaw %.1f  pitch %.1f", requiredYaw, requiredPitch));
        event.text.add(String.format("  current  yaw %.1f  pitch %.1f", p.rotationYaw, p.rotationPitch));
        event.text.add(String.format("  aim offset %.1f deg | reach valid %s | LOS %s",
                aimOffset >= 0.0D ? aimOffset : Double.NaN,
                step != null && step.distance <= reach + 0.05D,
                step != null ? step.lineOfSight : "-"));
    }

    private String statusOf(BlockPos pos) {
        ConfirmationTracker.Result r = tracker.getResult(pos);
        return r.name();
    }
}
