package com.example.autoblock.geometry;

import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.Vec3;

/**
 * One block of the wall plus the exact face we must click to place it:
 * the solid neighbor block {@code clickedBlock}, the face {@code side} of
 * that block the new block attaches to, and the interaction point on that
 * face the camera must aim at.
 */
public class PlacementStep {

    public final BlockPos targetPos;        // where the block will be placed
    public final BlockPos clickedBlock;     // solid block whose face we click
    public final EnumFacing side;           // face of clickedBlock to click
    public final Vec3 interactionPoint;     // point on the face the camera aims at
    public final double distance;           // eye -> interaction point
    public final boolean lineOfSight;
    public final double score;

    public PlacementStep(BlockPos targetPos, BlockPos clickedBlock, EnumFacing side,
                         Vec3 interactionPoint, double distance, boolean lineOfSight, double score) {
        this.targetPos = targetPos;
        this.clickedBlock = clickedBlock;
        this.side = side;
        this.interactionPoint = interactionPoint;
        this.distance = distance;
        this.lineOfSight = lineOfSight;
        this.score = score;
    }

    /** Center of a block. */
    public static Vec3 blockCenter(BlockPos pos) {
        return new Vec3(pos.getX() + 0.5D, pos.getY() + 0.5D, pos.getZ() + 0.5D);
    }

    /** Center of the given face of a block (the point you would click). */
    public static Vec3 faceCenter(BlockPos clicked, EnumFacing side) {
        return new Vec3(
                clicked.getX() + 0.5D + side.getFrontOffsetX() * 0.5D,
                clicked.getY() + 0.5D + side.getFrontOffsetY() * 0.5D,
                clicked.getZ() + 0.5D + side.getFrontOffsetZ() * 0.5D);
    }

    @Override
    public String toString() {
        return "PlacementStep{" + targetPos + " face=" + side + " via " + clickedBlock + "}";
    }
}
