package com.example.autoblock.render;

import com.example.autoblock.config.ModConfig;
import com.example.autoblock.geometry.PlacementPlan;
import com.example.autoblock.geometry.PlacementStep;
import com.example.autoblock.network.NetworkDiagnostics;
import com.example.autoblock.placement.ConfirmationTracker;
import com.example.autoblock.placement.PlacementController;
import com.example.autoblock.target.MovementPredictor;
import com.example.autoblock.target.TargetDetector;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.GL11;

/**
 * World-space debug visualization (F10 / /autoblock viz): the predicted
 * wall, predicted and current target positions, movement vector, player eye,
 * current placement face and reach line.
 */
public class DebugRenderer {

    private final ModConfig config;
    private final PlacementController controller;
    private final TargetDetector detector;
    private final MovementPredictor predictor;
    private final NetworkDiagnostics network;
    private final ConfirmationTracker tracker;

    public DebugRenderer(ModConfig config, PlacementController controller, TargetDetector detector,
                         MovementPredictor predictor, NetworkDiagnostics network, ConfirmationTracker tracker) {
        this.config = config;
        this.controller = controller;
        this.detector = detector;
        this.predictor = predictor;
        this.network = network;
        this.tracker = tracker;
    }

    @SubscribeEvent
    public void onRenderWorldLast(RenderWorldLastEvent event) {
        if (!config.showVisualization) {
            return;
        }
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.theWorld == null || mc.getRenderManager().renderViewEntity == null) {
            return;
        }
        Entity viewer = mc.getRenderManager().renderViewEntity;
        float pt = event.getPartialTicks();
        double vx = viewer.lastTickPosX + (viewer.posX - viewer.lastTickPosX) * pt;
        double vy = viewer.lastTickPosY + (viewer.posY - viewer.lastTickPosY) * pt;
        double vz = viewer.lastTickPosZ + (viewer.posZ - viewer.lastTickPosZ) * pt;

        GL11.glPushMatrix();
        GL11.glTranslated(-vx, -vy, -vz);
        try {
            renderAll(mc, pt);
        } finally {
            GL11.glPopMatrix();
        }
    }

    private void renderAll(Minecraft mc, float pt) {
        PlacementPlan plan = controller.getPlan();
        PlacementStep step = controller.getCurrentStep();
        EntityPlayer target = detector.getTarget();
        Vec3 predicted = controller.getPredicted();
        double reach = controller.effectiveReachForDisplay(mc);
        Vec3 eye = mc.thePlayer != null ? mc.thePlayer.getPositionEyes(1.0F) : null;

        // predicted wall
        if (plan != null) {
            for (BlockPos pos : plan.all()) {
                boolean ok = eye != null && eye.distanceTo(PlacementStep.blockCenter(pos)) <= reach + 0.05D;
                drawBoxOutline(pos, ok ? 0.2F : 1.0F, ok ? 1.0F : 0.2F, 0.2F, 1.0F, 2.0F);
            }
            drawLabel(mc, "WALL", plan.center.getX() + 0.5D, plan.center.getY() + 1.6D, plan.center.getZ() + 0.5D, 0xFFFFFFFF);
        }

        // current placement face
        if (step != null) {
            drawFace(step, 1.0F, 1.0F, 0.0F, 0.55F);
            drawPoint(step.interactionPoint, 1.0F, 1.0F, 0.0F, 5.0F);
            if (eye != null) {
                boolean ok = step.distance <= reach + 0.05D && step.lineOfSight;
                drawLine(eye.xCoord, eye.yCoord, eye.zCoord,
                        step.interactionPoint.xCoord, step.interactionPoint.yCoord, step.interactionPoint.zCoord,
                        ok ? 0.2F : 1.0F, ok ? 1.0F : 0.2F, 0.2F, 0.9F, 1.5F);
            }
            drawLabel(mc, "FACE " + step.side, step.interactionPoint.xCoord,
                    step.interactionPoint.yCoord + 0.3D, step.interactionPoint.zCoord, 0xFFFFFF00);
        }

        // prediction marker + movement vector
        if (target != null) {
            Vec3 c = target.getPositionEyes(1.0F);
            drawCross(c, 0.25D, 1.0F, 0.3F, 0.3F, 2.5F);
            drawLabel(mc, "TARGET " + target.getName(), target.posX, target.posY + 2.2D, target.posZ, 0xFFFF5555);
            if (predicted != null) {
                Vec3 feet = new Vec3(predicted.xCoord, predicted.yCoord, predicted.zCoord);
                drawCross(feet, 0.25D, 0.3F, 0.4F, 1.0F, 2.5F);
                drawLine(target.posX, target.posY + 1.0D, target.posZ,
                        feet.xCoord, feet.yCoord + 1.0D, feet.zCoord, 1.0F, 1.0F, 0.2F, 0.9F, 2.0F);
                drawLabel(mc, "PREDICTED", feet.xCoord, feet.yCoord + 1.2D, feet.zCoord, 0xFF55FFFF);
            }
        } else if (predicted != null) {
            drawCross(predicted, 0.25D, 0.3F, 0.4F, 1.0F, 2.5F);
            drawLabel(mc, "PREDICTED", predicted.xCoord, predicted.yCoord + 1.2D, predicted.zCoord, 0xFF55FFFF);
        }

        // player eye
        if (eye != null) {
            drawCross(eye, 0.15D, 1.0F, 1.0F, 1.0F, 2.0F);
            drawLabel(mc, "EYE", eye.xCoord, eye.yCoord + 0.4D, eye.zCoord, 0xFFFFFFFF);
        }

        // per-block status ticks
        if (plan != null) {
            for (BlockPos pos : plan.all()) {
                ConfirmationTracker.Result r = tracker.getResult(pos);
                if (r != ConfirmationTracker.Result.WAITING) {
                    drawLabel(mc, plan.label(pos) + " " + r.name(),
                            pos.getX() + 0.5D, pos.getY() + 1.1D, pos.getZ() + 0.5D,
                            r == ConfirmationTracker.Result.CONFIRMED ? 0xFF55FF55 : 0xFFFF5555);
                }
            }
        }
    }

    // ------------------------------------------------------------------
    // primitives
    // ------------------------------------------------------------------

    private void drawBoxOutline(BlockPos pos, float r, float g, float b, float a, float width) {
        double x0 = pos.getX(), y0 = pos.getY(), z0 = pos.getZ();
        double x1 = x0 + 1.0D, y1 = y0 + 1.0D, z1 = z0 + 1.0D;
        Tessellator t = Tessellator.getInstance();
        WorldRenderer wr = t.getWorldRenderer();
        GlStateManager.disableTexture2D();
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GlStateManager.disableCull();
        GL11.glLineWidth(width);
        wr.begin(GL11.GL_LINES, DefaultVertexFormats.POSITION_COLOR);
        addEdge(wr, x0, y0, z0, x1, y0, z0, r, g, b, a);
        addEdge(wr, x1, y0, z0, x1, y1, z0, r, g, b, a);
        addEdge(wr, x1, y1, z0, x0, y1, z0, r, g, b, a);
        addEdge(wr, x0, y1, z0, x0, y0, z0, r, g, b, a);
        addEdge(wr, x0, y0, z1, x1, y0, z1, r, g, b, a);
        addEdge(wr, x1, y0, z1, x1, y1, z1, r, g, b, a);
        addEdge(wr, x1, y1, z1, x0, y1, z1, r, g, b, a);
        addEdge(wr, x0, y1, z1, x0, y0, z1, r, g, b, a);
        addEdge(wr, x0, y0, z0, x0, y0, z1, r, g, b, a);
        addEdge(wr, x1, y0, z0, x1, y0, z1, r, g, b, a);
        addEdge(wr, x1, y1, z0, x1, y1, z1, r, g, b, a);
        addEdge(wr, x0, y1, z0, x0, y1, z1, r, g, b, a);
        t.draw();
        GlStateManager.enableCull();
        GlStateManager.disableBlend();
        GlStateManager.enableTexture2D();
    }

    private void addEdge(WorldRenderer wr, double x1, double y1, double z1,
                         double x2, double y2, double z2, float r, float g, float b, float a) {
        wr.pos(x1, y1, z1).color(r, g, b, a).endVertex();
        wr.pos(x2, y2, z2).color(r, g, b, a).endVertex();
    }

    private void drawLine(double x1, double y1, double z1, double x2, double y2, double z2,
                          float r, float g, float b, float a, float width) {
        Tessellator t = Tessellator.getInstance();
        WorldRenderer wr = t.getWorldRenderer();
        GlStateManager.disableTexture2D();
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GlStateManager.disableDepth();
        GL11.glLineWidth(width);
        wr.begin(GL11.GL_LINES, DefaultVertexFormats.POSITION_COLOR);
        addEdge(wr, x1, y1, z1, x2, y2, z2, r, g, b, a);
        t.draw();
        GlStateManager.enableDepth();
        GlStateManager.disableBlend();
        GlStateManager.enableTexture2D();
    }

    /** Small 3D cross centered on a point. */
    private void drawCross(Vec3 c, double half, float r, float g, float b, float width) {
        drawLine(c.xCoord - half, c.yCoord, c.zCoord, c.xCoord + half, c.yCoord, c.zCoord, r, g, b, 0.9F, width);
        drawLine(c.xCoord, c.yCoord - half, c.zCoord, c.xCoord, c.yCoord + half, c.zCoord, r, g, b, 0.9F, width);
        drawLine(c.xCoord, c.yCoord, c.zCoord - half, c.xCoord, c.yCoord, c.zCoord + half, r, g, b, 0.9F, width);
    }

    private void drawPoint(Vec3 p, float r, float g, float b, float width) {
        drawLine(p.xCoord - 0.1D, p.yCoord, p.zCoord, p.xCoord + 0.1D, p.yCoord, p.zCoord, r, g, b, 1.0F, width);
        drawLine(p.xCoord, p.yCoord - 0.1D, p.zCoord, p.xCoord, p.yCoord + 0.1D, p.zCoord, r, g, b, 1.0F, width);
    }

    /** Translucent quad just in front of the placement face. */
    private void drawFace(PlacementStep step, float r, float g, float b, float a) {
        EnumFacing f = step.side;
        double nx = f.getFrontOffsetX(), ny = f.getFrontOffsetY(), nz = f.getFrontOffsetZ();
        double ux, uy, uz, vx, vy, vz;
        if (Math.abs(nx) > 0.001D) {
            ux = 0; uy = 1; uz = 0;
            vx = 0; vy = 0; vz = 1;
        } else if (Math.abs(ny) > 0.001D) {
            ux = 1; uy = 0; uz = 0;
            vx = 0; vy = 0; vz = 1;
        } else {
            ux = 1; uy = 0; uz = 0;
            vx = 0; vy = 1; vz = 0;
        }
        Vec3 c = step.interactionPoint;
        double ox = c.xCoord + nx * 0.002D, oy = c.yCoord + ny * 0.002D, oz = c.zCoord + nz * 0.002D;
        double[][] corners = new double[][]{
                {ox - 0.5D * ux - 0.5D * vx, oy - 0.5D * uy - 0.5D * vy, oz - 0.5D * uz - 0.5D * vz},
                {ox + 0.5D * ux - 0.5D * vx, oy + 0.5D * uy - 0.5D * vy, oz + 0.5D * uz - 0.5D * vz},
                {ox + 0.5D * ux + 0.5D * vx, oy + 0.5D * uy + 0.5D * vy, oz + 0.5D * uz + 0.5D * vz},
                {ox - 0.5D * ux + 0.5D * vx, oy - 0.5D * uy + 0.5D * vy, oz - 0.5D * uz + 0.5D * vz}};
        Tessellator t = Tessellator.getInstance();
        WorldRenderer wr = t.getWorldRenderer();
        GlStateManager.disableTexture2D();
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GlStateManager.disableCull();
        wr.begin(GL11.GL_QUADS, DefaultVertexFormats.POSITION_COLOR);
        for (double[] cor : corners) {
            wr.pos(cor[0], cor[1], cor[2]).color(r, g, b, a).endVertex();
        }
        t.draw();
        GlStateManager.enableCull();
        GlStateManager.disableBlend();
        GlStateManager.enableTexture2D();
    }

    private void drawLabel(Minecraft mc, String text, double x, double y, double z, int color) {
        Entity viewer = mc.getRenderManager().renderViewEntity;
        if (viewer == null) {
            return;
        }
        double dx = x - viewer.posX;
        double dy = y - viewer.posY;
        double dz = z - viewer.posZ;
        double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (dist > 64.0D) {
            return;
        }
        float scale = MathHelper.clamp_float((float) (dist * 0.02D), 0.3F, 1.6F);
        GL11.glPushMatrix();
        GL11.glTranslatef((float) dx, (float) dy, (float) dz);
        GL11.glRotatef(-mc.getRenderManager().playerViewY, 0.0F, 1.0F, 0.0F);
        GL11.glRotatef(mc.getRenderManager().playerViewX, 1.0F, 0.0F, 0.0F);
        GL11.glScalef(-scale, -scale, scale);
        GlStateManager.enableBlend();
        GlStateManager.disableDepth();
        int w = mc.fontRendererObj.getStringWidth(text);
        mc.fontRendererObj.drawString(text, -w / 2, 0, color);
        GlStateManager.enableDepth();
        GlStateManager.disableBlend();
        GL11.glPopMatrix();
    }
}
