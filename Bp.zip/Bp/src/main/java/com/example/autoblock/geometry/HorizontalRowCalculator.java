package com.example.autoblock.geometry;

import com.example.autoblock.config.ModConfig;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;

/**
 * Computes the three wall block positions from the predicted target position.
 *
 * The wall is a horizontal row perpendicular to the target's horizontal
 * movement: center = block under the predicted target position (plus an
 * optional lead), left/right extend one block along the perpendicular.
 */
public class HorizontalRowCalculator {

    private final ModConfig config;

    public HorizontalRowCalculator(ModConfig config) {
        this.config = config;
    }

    /**
     * @param direction normalized horizontal movement direction (or null when static)
     * @return the plan, or null when the target is effectively static
     */
    public PlacementPlan compute(EntityPlayer target, Vec3 predicted, Vec3 direction, double speed) {
        if (direction == null || speed < 1.0e-6D) {
            return null;
        }
        double dx = direction.xCoord;
        double dz = direction.zCoord;
        double perpX = -dz;
        double perpZ = dx;

        double lead = config.wallLeadBlocks;
        double cx = predicted.xCoord + dx * lead;
        double cz = predicted.zCoord + dz * lead;

        int centerX = MathHelper.floor_double(cx + 0.5D);
        int centerZ = MathHelper.floor_double(cz + 0.5D);
        int wallY = MathHelper.floor_double(predicted.yCoord);

        int roX = (int) Math.round(perpX);
        int roZ = (int) Math.round(perpZ);
        if (roX == 0 && roZ == 0) {
            roX = 1;
            roZ = 0;
        }

        BlockPos center = new BlockPos(centerX, wallY, centerZ);
        BlockPos left = center.add(roX, 0, roZ);
        BlockPos right = center.add(-roX, 0, -roZ);
        return new PlacementPlan(left, center, right, predicted, direction, perpX, perpZ, wallY);
    }
}
