package com.example.autoblock.placement;

import java.util.ArrayList;
import java.util.List;

import com.example.autoblock.config.ModConfig;
import com.example.autoblock.geometry.HorizontalRowCalculator;
import com.example.autoblock.geometry.PlacementPlan;
import com.example.autoblock.geometry.PlacementStep;
import com.example.autoblock.network.NetworkDiagnostics;
import com.example.autoblock.player.PlayerReachSolver;
import com.example.autoblock.rotation.RotationController;
import com.example.autoblock.target.MovementPredictor;
import com.example.autoblock.target.TargetDetector;

import net.minecraft.block.Block;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;

/**
 * The placement state machine. Driven entirely from the client tick event;
 * no Thread.sleep, never blocks the main thread.
 *
 * Per-block states (VALIDATE / ROTATE_TO / VERIFY_VIEW / PLACE / CONFIRM)
 * run once per wall block, indexed 1..3 (see {@link #getStateName()}).
 *
 * Recovery: TARGET_CHANGED / PLACEMENT_INVALID / OUT_OF_REACH /
 * BLOCK_REJECTED / WORLD_CHANGED / TARGET_LOST all transition into
 * RECALCULATE (or ABORT after too many attempts).
 */
public class PlacementController {

    private enum State {
        IDLE,
        TARGET_FOUND,
        PREDICT_TARGET,
        CALCULATE_ROW,
        SOLVE_REACH,
        VALIDATE,
        ROTATE_TO,
        VERIFY_VIEW,
        PLACE,
        CONFIRM,
        COMPLETE,
        RECALCULATE,
        ABORT
    }

    private final ModConfig config;
    private final TargetDetector detector;
    private final MovementPredictor predictor;
    private final HorizontalRowCalculator rowCalculator;
    private final PlayerReachSolver reachSolver;
    private final PlacementValidator validator;
    private final RotationController rotationController;
    private final ConfirmationTracker tracker;
    private final NetworkDiagnostics network;

    private State state = State.IDLE;
    private long stateTick = 0L;
    private int stepIndex = 0;
    private int recalcCount = 0;
    private int blockRetries = 0;
    private String lastMessage = "";

    private PlacementPlan plan;
    private List<BlockPos> order;
    private PlacementStep currentStep;
    private Vec3 predicted;
    private Vec3 planDirection;

    private EntityPlayer lastTrackedTarget;

    public PlacementController(ModConfig config, TargetDetector detector, MovementPredictor predictor,
                               HorizontalRowCalculator rowCalculator, PlayerReachSolver reachSolver,
                               PlacementValidator validator, RotationController rotationController,
                               ConfirmationTracker tracker, NetworkDiagnostics network) {
        this.config = config;
        this.detector = detector;
        this.predictor = predictor;
        this.rowCalculator = rowCalculator;
        this.reachSolver = reachSolver;
        this.validator = validator;
        this.rotationController = rotationController;
        this.tracker = tracker;
        this.network = network;
    }

    public void onClientTick(Minecraft mc) {
        network.onClientTick();
        long tick = mc.theWorld.getTotalWorldTime();

        if (!config.enabled) {
            reset();
            state = State.IDLE;
            return;
        }

        detector.updateTick();
        tracker.onClientTick(mc);
        EntityPlayer target = detector.getTarget();

        if (target != lastTrackedTarget) {
            lastTrackedTarget = target;
            predictor.reset();
        }

        if (state == State.IDLE) {
            if (target != null) {
                predictor.sample(target.posX, target.posY, target.posZ);
                if (predictor.hasData() && isApproaching(mc, target)) {
                    enter(State.TARGET_FOUND, tick);
                }
            }
            return;
        }

        // --- in-sequence guards ---
        if (target == null) {
            abort("Target lost");
            return;
        }
        if (state != State.COMPLETE && state != State.RECALCULATE && state != State.ABORT) {
            predictor.sample(target.posX, target.posY, target.posZ);
            if (plan != null && planDirection != null) {
                Vec3 dir = predictor.getDirectionHoriz();
                if (dir != null && RotationController.angleDeg(planDirection, dir) > config.recalcDirectionChangeDeg) {
                    recalc("Target changed direction");
                    return;
                }
                double drift = distance2d(predicted, target.posX, target.posZ);
                if (drift > config.recalcDistanceBlocks) {
                    recalc("Target drifted from prediction");
                    return;
                }
            }
        }

        switch (state) {
            case TARGET_FOUND: {
                if (!isApproaching(mc, target)) {
                    enter(State.IDLE, tick);
                    break;
                }
                predicted = predictor.predict();
                if (predicted == null) {
                    enter(State.IDLE, tick);
                    break;
                }
                enter(State.PREDICT_TARGET, tick);
                break;
            }
            case PREDICT_TARGET: {
                predicted = predictor.predict();
                if (predicted == null) {
                    enter(State.IDLE, tick);
                    break;
                }
                plan = rowCalculator.compute(target, predicted, predictor.getDirectionHoriz(), predictor.getSpeedHoriz());
                if (plan == null) {
                    enter(State.IDLE, tick);
                    break;
                }
                if (!validator.planBlocksFree(plan, mc.theWorld)) {
                    recalc("Wall space occupied");
                    break;
                }
                planDirection = predictor.getDirectionHoriz();
                enter(State.CALCULATE_ROW, tick);
                break;
            }
            case CALCULATE_ROW: {
                Vec3 eye = mc.thePlayer.getPositionEyes(1.0F);
                double reach = effectiveReach(mc);
                PlayerReachSolver.ReachResult r = reachSolver.solve(mc.thePlayer, eye, reach, plan);
                if (!r.allReachable) {
                    recalc("Player out of reach");
                    break;
                }
                order = validator.findOrder(plan, mc.theWorld, eye, reach);
                if (order == null || order.size() != 3) {
                    recalc("No valid placement faces");
                    break;
                }
                stepIndex = 0;
                blockRetries = 0;
                currentStep = null;
                enter(State.VALIDATE, tick);
                break;
            }
            case VALIDATE: {
                currentStep = validator.selectStep(mc.theWorld, mc.thePlayer.getPositionEyes(1.0F),
                        effectiveReach(mc), order.get(stepIndex));
                if (currentStep == null) {
                    recalc("Block placement invalid");
                    break;
                }
                enter(State.ROTATE_TO, tick);
                break;
            }
            case ROTATE_TO: {
                Vec3 eye = mc.thePlayer.getPositionEyes(1.0F);
                if (currentStep == null) {
                    recalc("Placement step lost");
                    break;
                }
                float yaw = RotationController.yawTo(eye, currentStep.interactionPoint);
                float pitch = RotationController.pitchTo(eye, currentStep.interactionPoint);
                if (rotationController.tickTo(mc.thePlayer, yaw, pitch)) {
                    enter(State.VERIFY_VIEW, tick);
                }
                break;
            }
            case VERIFY_VIEW: {
                Vec3 eye = mc.thePlayer.getPositionEyes(1.0F);
                double reach = effectiveReach(mc);
                if (currentStep == null) {
                    recalc("Placement step lost");
                    break;
                }
                Vec3 look = RotationController.lookVec(mc.thePlayer.rotationYaw, mc.thePlayer.rotationPitch);
                Vec3 dir = currentStep.interactionPoint.subtract(eye);
                double len = dir.lengthVector();
                if (len < 1.0e-9D) {
                    recalc("Placement point coincides with eye");
                    break;
                }
                dir = dir.scale(1.0D / len);
                double angle = RotationController.angleDeg(look, dir);
                if (angle <= config.rotationToleranceDeg * 1.5D
                        && validator.stepStillValid(mc.theWorld, currentStep, eye, reach)) {
                    enter(State.PLACE, tick);
                } else if (angle > config.rotationToleranceDeg * 2.0D) {
                    enter(State.ROTATE_TO, tick);
                } else {
                    recalc("View verification failed");
                }
                break;
            }
            case PLACE: {
                if (mc.currentScreen != null) {
                    break;
                }
                if (mc.thePlayer.isDead || mc.thePlayer.isPlayerSleeping()) {
                    abort("Player unavailable");
                    break;
                }
                if (currentStep == null) {
                    recalc("Placement step lost");
                    break;
                }
                int slot = findBlockSlot(mc);
                if (slot < 0) {
                    abort("Out of blocks");
                    break;
                }
                mc.thePlayer.inventory.currentItem = slot;
                ItemStack held = mc.thePlayer.getHeldItem();
                if (held == null || !(held.getItem() instanceof ItemBlock)) {
                    abort("Held item is not a block");
                    break;
                }
                if (config.swingOnPlace) {
                    mc.thePlayer.swingItem();
                }
                Block expected = ((ItemBlock) held.getItem()).getBlock();
                network.markPlacementSent();
                mc.playerController.onPlayerRightClick(mc.thePlayer, (WorldClient) mc.theWorld, held,
                        currentStep.clickedBlock, currentStep.side, currentStep.interactionPoint);
                tracker.registerPlacement(currentStep.targetPos, expected);
                enter(State.CONFIRM, tick);
                break;
            }
            case CONFIRM: {
                if (currentStep == null) {
                    recalc("Placement step lost");
                    break;
                }
                ConfirmationTracker.Result r = tracker.getResult(currentStep.targetPos);
                switch (r) {
                    case WAITING:
                        break;
                    case CONFIRMED:
                        network.markPlacementConfirmed();
                        stepIndex++;
                        if (stepIndex >= 3) {
                            enter(State.COMPLETE, tick);
                        } else {
                            blockRetries = 0;
                            enter(State.VALIDATE, tick);
                        }
                        break;
                    case FAILED:
                        blockRetries++;
                        if (blockRetries > config.maxRetriesPerBlock) {
                            recalc("Block rejected by world");
                        } else {
                            currentStep = null;
                            enter(State.VALIDATE, tick);
                        }
                        break;
                }
                break;
            }
            case COMPLETE: {
                if (tick - stateTick >= config.completeCooldownTicks) {
                    reset();
                    enter(State.IDLE, tick);
                }
                break;
            }
            case RECALCULATE: {
                if (recalcCount > config.maxRecalc) {
                    abort("Too many recalculations");
                    break;
                }
                if (tick - stateTick >= config.recalcCooldownTicks) {
                    clearSequence();
                    enter(State.IDLE, tick);
                }
                break;
            }
            case ABORT: {
                if (tick - stateTick >= config.abortCooldownTicks) {
                    recalcCount = 0;
                    reset();
                    enter(State.IDLE, tick);
                }
                break;
            }
            default:
                break;
        }
    }

    // ------------------------------------------------------------------
    // helpers
    // ------------------------------------------------------------------

    private boolean isApproaching(Minecraft mc, EntityPlayer target) {
        Vec3 v = predictor.getVelocity();
        if (v == null || predictor.getSpeedHoriz() < config.speedThreshold) {
            return false;
        }
        if (!config.requireApproach) {
            return true;
        }
        double dx = mc.thePlayer.posX - target.posX;
        double dz = mc.thePlayer.posZ - target.posZ;
        double d = Math.sqrt(dx * dx + dz * dz);
        if (d < 0.01D) {
            return true;
        }
        double cos = (v.xCoord * dx + v.zCoord * dz) / (predictor.getSpeedHoriz() * d);
        double angle = Math.toDegrees(Math.acos(MathHelper.clamp_double(cos, -1.0D, 1.0D)));
        return angle <= config.approachAngleDeg;
    }

    private double effectiveReach(Minecraft mc) {
        double reach = config.reachOverride > 0.0D ? config.reachOverride : mc.playerController.getBlockReachDistance();
        return Math.min(reach, 6.0D);
    }

    /** Reach used for display/debug purposes (clamped to the server limit). */
    public double effectiveReachForDisplay(Minecraft mc) {
        return effectiveReach(mc);
    }

    private int findBlockSlot(Minecraft mc) {
        ItemStack[] inv = mc.thePlayer.inventory.mainInventory;
        for (int i = 0; i < 9; i++) {
            ItemStack stack = inv[i];
            if (stack != null && stack.stackSize > 0 && stack.getItem() instanceof ItemBlock) {
                if (config.blockWhitelist.length > 0) {
                    String name = net.minecraft.block.Block.blockRegistry.getNameForObject(
                            ((ItemBlock) stack.getItem()).getBlock()).toString();
                    boolean allowed = false;
                    for (String w : config.blockWhitelist) {
                        if (w != null && w.equalsIgnoreCase(name)) {
                            allowed = true;
                            break;
                        }
                    }
                    if (!allowed) {
                        continue;
                    }
                }
                return i;
            }
        }
        return -1;
    }

    private double distance2d(Vec3 predicted, double x, double z) {
        if (predicted == null) {
            return 0.0D;
        }
        double dx = predicted.xCoord - x;
        double dz = predicted.zCoord - z;
        return Math.sqrt(dx * dx + dz * dz);
    }

    private void enter(State s, long tick) {
        if (state != s && config.debugLogging) {
            System.out.println("[AutoBlock] " + state + " -> " + s);
        }
        state = s;
        stateTick = tick;
    }

    private void recalc(String reason) {
        recalcCount++;
        lastMessage = reason;
        if (config.debugLogging) {
            System.out.println("[AutoBlock] Recalculate #" + recalcCount + ": " + reason);
        }
        clearSequence();
        enter(State.RECALCULATE, stateTick + 1);
    }

    private void abort(String reason) {
        lastMessage = reason;
        if (config.debugLogging) {
            System.out.println("[AutoBlock] Abort: " + reason);
        }
        clearSequence();
        enter(State.ABORT, stateTick + 1);
    }

    private void clearSequence() {
        plan = null;
        order = null;
        currentStep = null;
        predicted = null;
        planDirection = null;
        stepIndex = 0;
        blockRetries = 0;
        tracker.clear();
    }

    private void reset() {
        clearSequence();
        recalcCount = 0;
        lastMessage = "";
    }

    // ------------------------------------------------------------------
    // accessors for overlay / renderer / command
    // ------------------------------------------------------------------

    public String getStateName() {
        if (state == State.VALIDATE || state == State.ROTATE_TO
                || state == State.VERIFY_VIEW || state == State.PLACE || state == State.CONFIRM) {
            return state + "_BLOCK_" + (stepIndex + 1);
        }
        return state.toString();
    }

    public boolean isActive() {
        return state != State.IDLE;
    }

    public PlacementPlan getPlan() {
        return plan;
    }

    public PlacementStep getCurrentStep() {
        return currentStep;
    }

    public List<PlacementStep> getSteps(Minecraft mc) {
        if (plan == null || order == null) {
            return null;
        }
        Vec3 eye = mc.thePlayer.getPositionEyes(1.0F);
        double reach = effectiveReach(mc);
        List<PlacementStep> out = new ArrayList<PlacementStep>();
        for (BlockPos pos : order) {
            PlacementStep s = validator.selectStep(mc.theWorld, eye, reach, pos);
            if (s != null) {
                out.add(s);
            }
        }
        return out;
    }

    public List<BlockPos> getOrder() {
        return order;
    }

    public Vec3 getPredicted() {
        return predicted;
    }

    public String getLastMessage() {
        return lastMessage;
    }
}
