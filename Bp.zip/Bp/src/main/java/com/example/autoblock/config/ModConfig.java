package com.example.autoblock.config;

import java.io.File;

import net.minecraftforge.common.config.Configuration;

public class ModConfig {

    private final Configuration config;

    // ---- targeting ----
    public boolean enabled = true;
    public boolean autoTarget = true;
    public double targetRange = 32.0D;
    public double speedThreshold = 0.2D;
    public boolean requireApproach = true;
    public double approachAngleDeg = 100.0D;

    // ---- prediction ----
    public double predictionWindowTicks = 6.0D;
    public double maxPredictionSeconds = 1.0D;
    public double velocitySmoothing = 0.35D;
    public boolean trackAcceleration = true;
    public double accelerationSmoothing = 0.25D;
    public boolean latencyCompensation = true;

    // ---- recalculation ----
    public double recalcDirectionChangeDeg = 40.0D;
    public double recalcDistanceBlocks = 1.5D;
    public int maxRecalc = 10;
    public int recalcCooldownTicks = 6;

    // ---- placement ----
    public double wallLeadBlocks = 0.0D;
    public int maxRetriesPerBlock = 2;
    public int completeCooldownTicks = 20;
    public int abortCooldownTicks = 40;
    public boolean swingOnPlace = true;
    public boolean requireLineOfSight = true;
    public String[] blockWhitelist = new String[0];

    // ---- rotation ----
    public boolean snapRotation = false;
    public double rotationSpeedDegPerTick = 25.0D;
    public double rotationToleranceDeg = 2.0D;

    // ---- confirmation ----
    public int confirmMinDelayTicks = 3;
    public boolean adaptiveConfirmDelay = true;
    public int confirmTimeoutTicks = 30;

    // ---- reach ----
    public double reachOverride = 0.0D;

    // ---- debug ----
    public boolean showOverlay = false;
    public boolean showVisualization = false;
    public boolean debugLogging = false;

    public ModConfig(File file) {
        this.config = new Configuration(file);
        sync();
    }

    public void sync() {
        enabled = config.get("targeting", "enabled", enabled,
                "Master switch. When false the system is fully idle.").getBoolean();
        autoTarget = config.get("targeting", "autoTarget", autoTarget,
                "Automatically track the nearest player within range. Set false and use '/autoblock target set <name>' to lock a specific target.").getBoolean();
        targetRange = config.get("targeting", "targetRange", targetRange,
                "Maximum distance in blocks to auto-track a target.", 1.0D, 256.0D).getDouble();
        speedThreshold = config.get("targeting", "speedThreshold", speedThreshold,
                "Minimum horizontal speed (blocks/second) the target needs for the system to engage.", 0.0D, 50.0D).getDouble();
        requireApproach = config.get("targeting", "requireApproach", requireApproach,
                "Only engage when the target is actually moving toward the local player.").getBoolean();
        approachAngleDeg = config.get("targeting", "approachAngleDeg", approachAngleDeg,
                "Maximum angle in degrees between the target's movement direction and the direction toward the local player to count as 'approaching'. 90 = moving straight at the player.", 1.0D, 180.0D).getDouble();

        predictionWindowTicks = config.get("prediction", "predictionWindowTicks", predictionWindowTicks,
                "How far into the future (in client ticks) the target position is predicted.", 0.0D, 40.0D).getDouble();
        maxPredictionSeconds = config.get("prediction", "maxPredictionSeconds", maxPredictionSeconds,
                "Hard cap for the prediction window in seconds.", 0.05D, 5.0D).getDouble();
        velocitySmoothing = config.get("prediction", "velocitySmoothing", velocitySmoothing,
                "EMA smoothing factor for velocity (0..1). Higher = reacts faster, lower = more stable.", 0.01D, 1.0D).getDouble();
        trackAcceleration = config.get("prediction", "trackAcceleration", trackAcceleration,
                "Also estimate acceleration and apply it to the prediction.").getBoolean();
        accelerationSmoothing = config.get("prediction", "accelerationSmoothing", accelerationSmoothing,
                "EMA smoothing factor for acceleration (0..1).", 0.01D, 1.0D).getDouble();
        latencyCompensation = config.get("prediction", "latencyCompensation", latencyCompensation,
                "Add the estimated network RTT to the prediction window.").getBoolean();

        recalcDirectionChangeDeg = config.get("recalculation", "recalcDirectionChangeDeg", recalcDirectionChangeDeg,
                "If the target's movement direction changes by more than this angle mid-sequence, the plan is recalculated.", 1.0D, 180.0D).getDouble();
        recalcDistanceBlocks = config.get("recalculation", "recalcDistanceBlocks", recalcDistanceBlocks,
                "If the target drifts farther than this from the predicted position mid-sequence, the plan is recalculated.", 0.1D, 16.0D).getDouble();
        maxRecalc = config.get("recalculation", "maxRecalc", maxRecalc,
                "Maximum consecutive recalculations before aborting.", 1, 100).getInt();
        recalcCooldownTicks = config.get("recalculation", "recalcCooldownTicks", recalcCooldownTicks,
                "Ticks to wait between recalculations.", 1, 100).getInt();

        wallLeadBlocks = config.get("placement", "wallLeadBlocks", wallLeadBlocks,
                "Extra offset in blocks placed along the target's movement direction ahead of the predicted position.", -5.0D, 5.0D).getDouble();
        maxRetriesPerBlock = config.get("placement", "maxRetriesPerBlock", maxRetriesPerBlock,
                "How many times a single wall block is retried after a failed confirmation before the whole plan is recalculated.", 0, 10).getInt();
        completeCooldownTicks = config.get("placement", "completeCooldownTicks", completeCooldownTicks,
                "Idle ticks after a completed wall before a new sequence may start.", 0, 200).getInt();
        abortCooldownTicks = config.get("placement", "abortCooldownTicks", abortCooldownTicks,
                "Idle ticks after an aborted sequence.", 0, 400).getInt();
        swingOnPlace = config.get("placement", "swingOnPlace", swingOnPlace,
                "Send the arm swing animation before each placement (pure visual realism, server is unaffected).").getBoolean();
        requireLineOfSight = config.get("placement", "requireLineOfSight", requireLineOfSight,
                "Only use placement faces with an unobstructed view from the player's eye.").getBoolean();
        blockWhitelist = config.getStringList("blockWhitelist", "placement", blockWhitelist,
                "Registry names of allowed wall blocks, e.g. minecraft:cobblestone. Empty = any block item.");

        snapRotation = config.get("rotation", "snapRotation", snapRotation,
                "Instantly snap the camera to the required angle instead of rotating smoothly.").getBoolean();
        rotationSpeedDegPerTick = config.get("rotation", "rotationSpeedDegPerTick", rotationSpeedDegPerTick,
                "Maximum camera rotation speed in degrees per client tick.", 1.0D, 360.0D).getDouble();
        rotationToleranceDeg = config.get("rotation", "rotationToleranceDeg", rotationToleranceDeg,
                "Rotation convergence tolerance in degrees.", 0.1D, 20.0D).getDouble();

        confirmMinDelayTicks = config.get("confirmation", "confirmMinDelayTicks", confirmMinDelayTicks,
                "Minimum ticks to wait after a placement before checking the authoritative world state.", 1, 100).getInt();
        adaptiveConfirmDelay = config.get("confirmation", "adaptiveConfirmDelay", adaptiveConfirmDelay,
                "Scale the confirmation wait with the estimated RTT when online.").getBoolean();
        confirmTimeoutTicks = config.get("confirmation", "confirmTimeoutTicks", confirmTimeoutTicks,
                "Ticks after which a placement without confirmation is declared FAILED.", 1, 400).getInt();

        reachOverride = config.get("reach", "reachOverride", reachOverride,
                "Optional reach override in blocks (0.0 = vanilla 4.5 survival / 5.0 creative). Never exceeds the server's 6.0 block limit.", 0.0D, 6.0D).getDouble();

        showOverlay = config.get("debug", "showOverlay", showOverlay,
                "Show the in-game debug overlay (toggle with F9 or /autoblock overlay).").getBoolean();
        showVisualization = config.get("debug", "showVisualization", showVisualization,
                "Render the predicted wall and analysis lines in the world (toggle with F10 or /autoblock viz).").getBoolean();
        debugLogging = config.get("debug", "debugLogging", debugLogging,
                "Log state transitions to the console.").getBoolean();

        if (config.hasChanged()) {
            config.save();
        }
    }

    public void reload() {
        config.load();
        sync();
    }
}
