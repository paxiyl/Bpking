package com.example.autoblock.placement;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.example.autoblock.config.ModConfig;
import com.example.autoblock.geometry.PlacementPlan;
import com.example.autoblock.geometry.PlacementStep;

import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.Vec3;
import net.minecraft.world.World;

/**
 * Finds legitimate placement faces for the wall blocks and picks a dynamic
 * placement order so every block can attach to a solid neighbor
 * (terrain, or an already-placed wall block).
 */
public class PlacementValidator {

    public static final double EPS = 0.05D;

    private final ModConfig config;

    public PlacementValidator(ModConfig config) {
        this.config = config;
    }

    /**
     * Chooses an order for the three wall positions. Every position must have
     * at least one valid face against terrain or an earlier position in the
     * order. Returns null when no order is feasible.
     */
    public List<BlockPos> findOrder(PlacementPlan plan, World world, Vec3 eye, double reach) {
        List<BlockPos[]> candidates = Arrays.asList(
                new BlockPos[]{plan.center, plan.left, plan.right},
                new BlockPos[]{plan.center, plan.right, plan.left},
                new BlockPos[]{plan.left, plan.center, plan.right},
                new BlockPos[]{plan.right, plan.center, plan.left});
        for (BlockPos[] order : candidates) {
            Set<BlockPos> supports = new HashSet<BlockPos>();
            boolean ok = true;
            for (BlockPos target : order) {
                if (hasAnyStep(world, eye, reach, target, supports)) {
                    supports.add(target);
                } else {
                    ok = false;
                    break;
                }
            }
            if (ok) {
                return Arrays.asList(order);
            }
        }
        return null;
    }

    private boolean hasAnyStep(World world, Vec3 eye, double reach, BlockPos target, Set<BlockPos> supports) {
        for (EnumFacing f : EnumFacing.VALUES) {
            BlockPos clicked = target.offset(f);
            if (supports.contains(clicked)) {
                return true;
            }
            IBlockState state = world.getBlockState(clicked);
            Block b = state.getBlock();
            if (b == Blocks.air || !b.isFullBlock()) {
                continue;
            }
            Vec3 point = PlacementStep.faceCenter(clicked, f);
            if (eye.distanceTo(point) > reach + EPS) {
                continue;
            }
            if (config.requireLineOfSight && !hasLineOfSight(world, eye, clicked, f, point)) {
                continue;
            }
            return true;
        }
        return false;
    }

    /**
     * Selects the best face for one wall block against the LIVE world
     * (which already contains previously confirmed wall blocks).
     */
    public PlacementStep selectStep(World world, Vec3 eye, double reach, BlockPos target) {
        PlacementStep best = null;
        for (EnumFacing f : EnumFacing.VALUES) {
            BlockPos clicked = target.offset(f);
            IBlockState state = world.getBlockState(clicked);
            Block b = state.getBlock();
            if (b == Blocks.air || !b.isFullBlock()) {
                continue;
            }
            Vec3 point = PlacementStep.faceCenter(clicked, f);
            double dist = eye.distanceTo(point);
            if (dist > reach + EPS) {
                continue;
            }
            boolean los = hasLineOfSight(world, eye, clicked, f, point);
            if (!los && config.requireLineOfSight) {
                continue;
            }
            // Score: distance first; prefer the face pointing at the player.
            double score = dist;
            if (!los) {
                score += 1000.0D;
            }
            double toward = (eye.xCoord - (clicked.getX() + 0.5D)) * f.getFrontOffsetX()
                    + (eye.yCoord - (clicked.getY() + 0.5D)) * f.getFrontOffsetY()
                    + (eye.zCoord - (clicked.getZ() + 0.5D)) * f.getFrontOffsetZ();
            if (toward < 0.0D) {
                score += 5.0D;
            }
            if (best == null || score < best.score) {
                best = new PlacementStep(target, clicked, f, point, dist, los, score);
            }
        }
        return best;
    }

    /** Re-validates a previously chosen face against the current world. */
    public boolean stepStillValid(World world, PlacementStep step, Vec3 eye, double reach) {
        if (!isFree(world, step.targetPos)) {
            return false;
        }
        IBlockState state = world.getBlockState(step.clickedBlock);
        Block b = state.getBlock();
        if (b == Blocks.air || !b.isFullBlock()) {
            return false;
        }
        if (eye.distanceTo(step.interactionPoint) > reach + EPS) {
            return false;
        }
        return !config.requireLineOfSight || hasLineOfSight(world, eye, step.clickedBlock, step.side, step.interactionPoint);
    }

    public boolean planBlocksFree(PlacementPlan plan, World world) {
        for (BlockPos p : plan.all()) {
            if (!isFree(world, p)) {
                return false;
            }
        }
        return true;
    }

    public boolean isFree(World world, BlockPos pos) {
        IBlockState state = world.getBlockState(pos);
        Block b = state.getBlock();
        return b == Blocks.air || b.isReplaceable(world, pos);
    }

    /**
     * True when the ray from the eye reaches the face without crossing any
     * other block first. The ray is expected to terminate on the clicked
     * block's face itself.
     */
    public static boolean hasLineOfSight(World world, Vec3 eye, BlockPos clicked, EnumFacing side, Vec3 point) {
        MovingObjectPosition mop = world.rayTraceBlocks(eye, point);
        if (mop == null) {
            return true;
        }
        if (mop.typeOfHit != MovingObjectPosition.MovingObjectType.BLOCK) {
            return false;
        }
        return mop.getBlockPos().equals(clicked) && mop.sideHit == side;
    }
}
