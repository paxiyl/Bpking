package com.example.autoblock.rotation;

import com.example.autoblock.config.ModConfig;

import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;

/**
 * Calculates the yaw/pitch required to aim at a placement face interaction
 * point and rotates the local player's actual camera through the normal
 * client tick system (no Thread.sleep, never blocks the main thread).
 */
public class RotationController {

    private final ModConfig config;

    public RotationController(ModConfig config) {
        this.config = config;
    }

    /**
     * Advance the player's actual rotation toward the target by at most
     * {@code rotationSpeedDegPerTick} degrees per call.
     *
     * @return true once converged within the configured tolerance
     */
    public boolean tickTo(EntityPlayerSP player, float targetYaw, float targetPitch) {
        if (config.snapRotation) {
            player.rotationYaw = targetYaw;
            player.rotationPitch = targetPitch;
            return true;
        }
        float dy = MathHelper.wrapAngleTo180_float(targetYaw - player.rotationYaw);
        float dp = MathHelper.wrapAngleTo180_float(targetPitch - player.rotationPitch);
        float step = (float) config.rotationSpeedDegPerTick;
        if (Math.abs(dy) > step) {
            player.rotationYaw += Math.copySign(step, dy);
        } else {
            player.rotationYaw = targetYaw;
        }
        if (Math.abs(dp) > step) {
            player.rotationPitch += Math.copySign(step, dp);
        } else {
            player.rotationPitch = targetPitch;
        }
        return Math.abs(dy) <= config.rotationToleranceDeg && Math.abs(dp) <= config.rotationToleranceDeg;
    }

    public static float yawTo(Vec3 eye, Vec3 point) {
        double dx = point.xCoord - eye.xCoord;
        double dz = point.zCoord - eye.zCoord;
        return MathHelper.wrapAngleTo180_float((float) (Math.atan2(-dx, dz) * 180.0D / Math.PI));
    }

    public static float pitchTo(Vec3 eye, Vec3 point) {
        double dx = point.xCoord - eye.xCoord;
        double dy = point.yCoord - eye.yCoord;
        double dz = point.zCoord - eye.zCoord;
        double horiz = Math.sqrt(dx * dx + dz * dz);
        if (horiz < 1.0e-9D) {
            return 0.0F;
        }
        float p = (float) Math.toDegrees(-Math.atan2(dy, horiz));
        return MathHelper.clamp_float(p, -89.0F, 89.0F);
    }

    /** Unit look vector for the given yaw/pitch (Minecraft convention). */
    public static Vec3 lookVec(float yaw, float pitch) {
        float y = (float) Math.toRadians(yaw);
        float p = (float) Math.toRadians(pitch);
        return new Vec3(
                -MathHelper.sin(y) * MathHelper.cos(p),
                -MathHelper.sin(p),
                MathHelper.cos(y) * MathHelper.cos(p));
    }

    /** Angle in degrees between two vectors (assumes normalized inputs). */
    public static double angleDeg(Vec3 a, Vec3 b) {
        double dot = MathHelper.clamp_double(a.dotProduct(b), -1.0D, 1.0D);
        return Math.toDegrees(Math.acos(dot));
    }
}
