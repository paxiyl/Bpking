package com.example.autoblock;

import com.example.autoblock.command.CommandAutoBlock;
import com.example.autoblock.config.ModConfig;
import com.example.autoblock.geometry.HorizontalRowCalculator;
import com.example.autoblock.network.NetworkDiagnostics;
import com.example.autoblock.placement.ConfirmationTracker;
import com.example.autoblock.placement.PlacementController;
import com.example.autoblock.placement.PlacementValidator;
import com.example.autoblock.player.PlayerReachSolver;
import com.example.autoblock.render.DebugOverlay;
import com.example.autoblock.render.DebugRenderer;
import com.example.autoblock.rotation.RotationController;
import com.example.autoblock.target.MovementPredictor;
import com.example.autoblock.target.TargetDetector;

import net.minecraft.client.Minecraft;
import net.minecraftforge.client.ClientCommandHandler;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

@Mod(modid = BuildConfig.MODID, name = BuildConfig.MODNAME, version = BuildConfig.VERSION, clientSideOnly = true)
public class AutoBlockMod {

    public static AutoBlockMod instance;

    public ModConfig config;
    public NetworkDiagnostics network;
    public TargetDetector targetDetector;
    public MovementPredictor predictor;
    public HorizontalRowCalculator rowCalculator;
    public PlayerReachSolver reachSolver;
    public RotationController rotationController;
    public PlacementValidator validator;
    public ConfirmationTracker tracker;
    public PlacementController controller;

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        instance = this;
        config = new ModConfig(event.getSuggestedConfigurationFile());
    }

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        network = new NetworkDiagnostics(config);
        targetDetector = new TargetDetector(config, network);
        predictor = new MovementPredictor(config, network);
        rowCalculator = new HorizontalRowCalculator(config);
        reachSolver = new PlayerReachSolver(config);
        rotationController = new RotationController(config);
        validator = new PlacementValidator(config);
        tracker = new ConfirmationTracker(config, network);
        controller = new PlacementController(config, targetDetector, predictor, rowCalculator,
                reachSolver, validator, rotationController, tracker, network);

        ClientCommandHandler.instance.registerCommand(new CommandAutoBlock());
        AutoBlockKeys.register();
        MinecraftForge.EVENT_BUS.register(new ClientTickHandler());
        MinecraftForge.EVENT_BUS.register(new DebugOverlay(config, controller, targetDetector, predictor, network, tracker));
        MinecraftForge.EVENT_BUS.register(new DebugRenderer(config, controller, targetDetector, predictor, network, tracker));
        MinecraftForge.EVENT_BUS.register(new AutoBlockKeys());
    }

    public static class ClientTickHandler {

        @SubscribeEvent
        public void onClientTick(TickEvent.ClientTickEvent event) {
            if (event.phase != TickEvent.Phase.END) {
                return;
            }
            Minecraft mc = Minecraft.getMinecraft();
            if (mc.thePlayer == null || mc.theWorld == null) {
                return;
            }
            if (instance != null && instance.controller != null) {
                instance.controller.onClientTick(mc);
            }
        }
    }
}
