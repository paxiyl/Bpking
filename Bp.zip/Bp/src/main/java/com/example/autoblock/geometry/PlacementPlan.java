package com.example.autoblock.geometry;

import net.minecraft.util.BlockPos;
import net.minecraft.util.Vec3;

/**
 * A horizontal three-block wall computed from the predicted target position.
 * The wall is perpendicular to the target's horizontal movement.
 */
public class PlacementPlan {

    public final BlockPos left;
    public final BlockPos center;
    public final BlockPos right;
    public final Vec3 predicted;
    public final Vec3 direction;
    public final double perpX;
    public final double perpZ;
    public final int wallY;

    public PlacementPlan(BlockPos left, BlockPos center, BlockPos right,
                         Vec3 predicted, Vec3 direction, double perpX, double perpZ, int wallY) {
        this.left = left;
        this.center = center;
        this.right = right;
        this.predicted = predicted;
        this.direction = direction;
        this.perpX = perpX;
        this.perpZ = perpZ;
        this.wallY = wallY;
    }

    public BlockPos get(int index) {
        switch (index) {
            case 0:
                return center;
            case 1:
                return left;
            default:
                return right;
        }
    }

    /** LEFT / CENTER / RIGHT label for overlay and debugging. */
    public String label(BlockPos pos) {
        if (pos.equals(left)) {
            return "Left";
        }
        if (pos.equals(center)) {
            return "Center";
        }
        if (pos.equals(right)) {
            return "Right";
        }
        return "?";
    }

    public BlockPos[] all() {
        return new BlockPos[]{center, left, right};
    }
}
