package com.example.autoblock.command;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.example.autoblock.AutoBlockMod;
import com.example.autoblock.config.ModConfig;
import com.example.autoblock.geometry.PlacementStep;
import com.example.autoblock.network.NetworkDiagnostics;
import com.example.autoblock.placement.ConfirmationTracker;
import com.example.autoblock.placement.PlacementController;
import com.example.autoblock.target.MovementPredictor;
import com.example.autoblock.target.TargetDetector;

import net.minecraft.command.CommandException;
import net.minecraft.command.ICommand;
import net.minecraft.command.ICommandSender;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.BlockPos;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.EnumChatFormatting;
import net.minecraft.util.Vec3;

public class CommandAutoBlock implements ICommand {

    @Override
    public String getCommandName() {
        return "autoblock";
    }

    @Override
    public String getCommandUsage(ICommandSender sender) {
        return "/autoblock <on|off|toggle|target <auto|set <name>|none>|overlay [on|off]|viz [on|off]|info|reload>";
    }

    @Override
    public List<String> getCommandAliases() {
        return Arrays.asList("ab");
    }

    @Override
    public void processCommand(ICommandSender sender, String[] args) throws CommandException {
        AutoBlockMod mod = AutoBlockMod.instance;
        if (mod == null) {
            msg(sender, EnumChatFormatting.RED + "AutoBlock is not loaded yet.");
            return;
        }
        ModConfig config = mod.config;
        if (args.length == 0) {
            msg(sender, EnumChatFormatting.GOLD + getCommandUsage(sender));
            return;
        }
        String cmd = args[0].toLowerCase();
        if (cmd.equals("on") || cmd.equals("enable")) {
            config.enabled = true;
            msg(sender, "AutoBlock enabled.");
        } else if (cmd.equals("off") || cmd.equals("disable")) {
            config.enabled = false;
            msg(sender, "AutoBlock disabled.");
        } else if (cmd.equals("toggle")) {
            config.enabled = !config.enabled;
            msg(sender, "AutoBlock " + (config.enabled ? "enabled" : "disabled") + ".");
        } else if (cmd.equals("target")) {
            if (args.length < 2) {
                TargetDetector detector = mod.targetDetector;
                EntityPlayer t = detector.getTarget();
                msg(sender, "Target mode: " + (detector.getLockedName() != null && !detector.getLockedName().isEmpty()
                        ? "locked to '" + detector.getLockedName() + "'" : (config.autoTarget ? "auto (nearest player)" : "none"))
                        + (t != null ? " | current target: " + t.getName() : " | no target in range"));
            } else if (args[1].equalsIgnoreCase("auto")) {
                mod.targetDetector.setLockedName("");
                config.autoTarget = true;
                msg(sender, "Target mode set to auto (nearest player).");
            } else if (args[1].equalsIgnoreCase("set")) {
                if (args.length < 3) {
                    msg(sender, EnumChatFormatting.RED + "Usage: /autoblock target set <playername>");
                    return;
                }
                mod.targetDetector.setLockedName(args[2]);
                config.autoTarget = false;
                msg(sender, "Target locked to '" + args[2] + "'.");
            } else if (args[1].equalsIgnoreCase("none")) {
                mod.targetDetector.setLockedName("");
                config.autoTarget = false;
                msg(sender, "Targeting disabled.");
            } else {
                msg(sender, EnumChatFormatting.RED + "Usage: /autoblock target <auto|set <name>|none>");
            }
        } else if (cmd.equals("overlay")) {
            if (args.length >= 2 && args[1].equalsIgnoreCase("on")) config.showOverlay = true;
            else if (args.length >= 2 && args[1].equalsIgnoreCase("off")) config.showOverlay = false;
            else config.showOverlay = !config.showOverlay;
            msg(sender, "Debug overlay " + (config.showOverlay ? "shown" : "hidden") + ".");
        } else if (cmd.equals("viz") || cmd.equals("visualization")) {
            if (args.length >= 2 && args[1].equalsIgnoreCase("on")) config.showVisualization = true;
            else if (args.length >= 2 && args[1].equalsIgnoreCase("off")) config.showVisualization = false;
            else config.showVisualization = !config.showVisualization;
            msg(sender, "World visualization " + (config.showVisualization ? "shown" : "hidden") + ".");
        } else if (cmd.equals("info")) {
            sendInfo(sender, mod);
        } else if (cmd.equals("reload")) {
            config.reload();
            msg(sender, "Config reloaded.");
        } else {
            msg(sender, EnumChatFormatting.RED + "Unknown subcommand '" + cmd + "'.");
        }
    }

    private void sendInfo(ICommandSender sender, AutoBlockMod mod) {
        ModConfig config = mod.config;
        PlacementController controller = mod.controller;
        TargetDetector detector = mod.targetDetector;
        MovementPredictor predictor = mod.predictor;
        NetworkDiagnostics network = mod.network;
        ConfirmationTracker tracker = mod.tracker;

        msg(sender, EnumChatFormatting.GOLD + "== AutoBlock ==");
        msg(sender, "Enabled: " + config.enabled + " | State: " + controller.getStateName());
        EntityPlayer t = detector.getTarget();
        if (t != null) {
            msg(sender, String.format("Target: %s | dist %.2f | speed %.2f b/s",
                    t.getName(), t.getDistanceToEntity(net.minecraft.client.Minecraft.getMinecraft().thePlayer), predictor.getSpeedHoriz()));
        } else {
            msg(sender, "Target: none");
        }
        Vec3 predicted = controller.getPredicted();
        if (predicted != null) {
            msg(sender, String.format("Predicted: %.2f %.2f %.2f (%.2fs ahead)",
                    predicted.xCoord, predicted.yCoord, predicted.zCoord, predictor.predictionSeconds()));
        }
        msg(sender, String.format("Network: RTT %.0f ms | tick %.1f ms | last placement delay %.0f ms",
                network.getRttMs(), network.getTickMs(), network.getLastPlacementDelayMs()));
        if (controller.getPlan() != null) {
            msg(sender, "Wall L/C/R: " + controller.getPlan().left + " / " + controller.getPlan().center + " / " + controller.getPlan().right);
        }
        List<PlacementStep> steps = controller.getSteps(net.minecraft.client.Minecraft.getMinecraft());
        if (steps != null) {
            for (PlacementStep s : steps) {
                msg(sender, "Step " + s.targetPos + " face=" + s.side + " via " + s.clickedBlock
                        + " | " + tracker.getResult(s.targetPos));
            }
        }
        if (controller.getLastMessage() != null && !controller.getLastMessage().isEmpty()) {
            msg(sender, "Last event: " + controller.getLastMessage());
        }
    }

    private void msg(ICommandSender sender, String text) {
        sender.addChatMessage(new ChatComponentText(text));
    }

    @Override
    public boolean canCommandSenderUseCommand(ICommandSender sender) {
        return true;
    }

    @Override
    public List<String> addTabCompletionOptions(ICommandSender sender, String[] args, BlockPos pos) {
        List<String> out = new ArrayList<String>();
        if (args.length == 1) {
            for (String s : new String[]{"on", "off", "toggle", "target", "overlay", "viz", "info", "reload"}) {
                if (s.startsWith(args[0].toLowerCase())) out.add(s);
            }
        } else if (args.length == 2 && args[0].equalsIgnoreCase("target")) {
            for (String s : new String[]{"auto", "set", "none"}) {
                if (s.startsWith(args[1].toLowerCase())) out.add(s);
            }
        } else if (args.length == 2 && (args[0].equalsIgnoreCase("overlay") || args[0].equalsIgnoreCase("viz"))) {
            for (String s : new String[]{"on", "off"}) {
                if (s.startsWith(args[1].toLowerCase())) out.add(s);
            }
        }
        return out;
    }

    @Override
    public boolean isUsernameIndex(String[] args, int index) {
        return false;
    }

    @Override
    public int compareTo(ICommand o) {
        return getCommandName().compareTo(o.getCommandName());
    }
}
